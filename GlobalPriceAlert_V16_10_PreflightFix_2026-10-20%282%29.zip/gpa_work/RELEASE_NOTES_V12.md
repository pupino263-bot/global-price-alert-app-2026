# Global Price Alert V12 — release-correctness pass

## Implemented in this iteration
- Android no longer lets a user create a definitive price-drop alert from an offer explicitly marked as an estimated/incomplete total.
- The offer card explains why alert creation is unavailable until the source provides a complete, verifiable cost.
- Release preflight now checks this guard to reduce the risk of regression.

## Verification performed
- `node scripts/release-preflight.mjs` — PASS.
- `npm test` in `backend/` — PASS (all four test groups).
- `node --check` for backend source, tests and scripts — PASS.
- ZIP integrity — PASS.

## Still not verified / blockers
- Full Gradle Android build and Compose compilation: not executable in the current environment because Gradle/Android SDK are unavailable and network access cannot download them.
- Android install/device regression and signed AAB.
- Live PostgreSQL migration/repository tests and production deployment.
- Live marketplace credentials/access, push delivery, Billing/ads/affiliate production integrations.
- Complete IT/EN/FR/ES/DE localization and Play Store compliance materials.

This is a correctness improvement to the development package, not a publishable release.

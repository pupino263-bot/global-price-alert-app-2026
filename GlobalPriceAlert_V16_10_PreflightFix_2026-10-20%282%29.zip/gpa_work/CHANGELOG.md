## V7 — PostgreSQL runtime and first authorized-source adapter
- Added PostgreSQL runtime storage selected by `DATABASE_URL`, including account/session, alert, history, click, entitlement and notification operations.
- Added checksum-verified SQL migration runner and snapshot taxes migration.
- Added eBay Browse API adapter with server-side client-credentials OAuth, token caching, marketplace selection and response normalization.
- Marked incomplete delivery/tax/mandatory-fee details as estimated and ranked complete cost breakdowns ahead of estimates.
- Extended effective-cost formula to include known taxes across source normalization, snapshot persistence and Android domain model.
- Prevented misleading raw numeric comparisons across currencies; mixed-currency groups now expose minima per currency until FX conversion is implemented.
- Added mocked provider tests, Docker deployment example and updated release gates.
- Live PostgreSQL, live eBay access, full Android build/signing and production deployment remain unverified.

# Changelog

## V6 — backend/API correctness and Android alert flow
- Preserved competing offers across different stores while removing same-source duplicate records.
- Added per-source timeouts/status, search validation, price history, alert cancellation, notification read state, session logout and account deletion.
- Server now computes snapshot effective cost from its breakdown and avoids triggering new alerts from older snapshots.
- Hardened JSON request parsing, content-type validation, session handling, outbound URL validation and login throttling.
- Consolidated PostgreSQL target schema and OpenAPI routes.
- Android gained account flow, server-backed alert creation and clear demo-mode messaging; release builds require a real HTTPS backend URL.
- Expanded cross-cutting category branches and added smokers/vaping category.
- Added CI workflow and expanded automated tests.

## Explicitly not included in V6
Live marketplace credentials/adapters, PostgreSQL runtime persistence, real affiliate networks, Play Billing verification, ads, FCM delivery, signed AAB and Play Console publication.

## V8 — automatic tracked-price refresh
- Alerts now retain search context and can be rechecked against configured authorized sources.
- Worker refreshes active tracked products before evaluating price-drop alerts; shared queries are grouped and rechecks throttled.
- Estimated totals are retained in history but excluded from definitive alert triggers.
- Android sends the search phrase/category/country when creating alerts.
- Added PostgreSQL migration 004 (including best-effort legacy alert query backfill) and monitoring tests.


## V9 — encrypted Android session and notification inbox
- Replaced in-memory-only Android session handling with AES-GCM encrypted token persistence using Android Keystore; local session is cleared on logout and invalidated on HTTP 401.
- Added a minimal authenticated notification inbox backed by existing notification APIs, including marking notifications as read.
- Masked password entry in the account dialog.
- Re-ran backend integration suite, Node syntax checks, pure Kotlin domain compilation, Android XML parsing and static wiring checks; all available checks passed.
- Full Android Gradle build and device verification remain pending because the required SDK/Gradle environment is unavailable here.


## V11 — Release preflight
- Added static preflight checks for release-critical project structure and safety rules.
- Added the preflight to Android CI before debug compilation and exposed a local npm script.
- Revalidated backend tests and JavaScript syntax checks.

## V12 — alert correctness for estimated totals (2026-10-12)
- Disabled definitive alert creation from offers whose effective total is explicitly estimated, non-finite, or non-positive.
- Added user-facing explanation that a complete, verifiable total is required before price alerts can be created.
- Extended release preflight to assert the estimated-cost alert guard.


## 17 ottobre 2026 — ampliamento tassonomia categorie
- Aggiunte nove categorie di primo livello per coprire esplicitamente gioielleria, artigianato/filati, tatuaggi, nutrizione sportiva, riscaldamento/energia, domotica/automazione, macchinari industriali, idraulica/trattamento acqua e software/servizi digitali.
- Ogni nuova categoria eredita automaticamente i rami trasversali già definiti: accessori, componenti/ricambi, consumabili, prodotti compatibili e varianti professionali/specialistiche.
- Il preflight ora verifica copertura minima e unicità dei nomi delle categorie principali.
- Verifica statica soltanto: non equivale a compilazione Android o verifica di tutte le stringhe UI.


## V16.3 — Smart Matching and effective-cost safety (2026-10-18)
- GTIN matching now validates standard GTIN lengths and GS1 check digits; malformed codes fall back to brand/model/title identity.
- Missing shipping, tax or mandatory-fee certainty now marks the total as estimated by default, preventing false exact-price comparisons and alert eligibility.
- Discounts exceeding the known gross amount are rejected rather than clamped to zero.
- Regression tests and release preflight now enforce these matching/cost-safety invariants.

## V16.4 — 2026-10-19
- Added variant-aware product identity so storage/color/size differences do not silently share one price-comparison group.
- Added conservative Smart Compatibility assessment and `POST /v1/compatibility/check` with evidence, explicit `unknown` state and verification disclaimer.
- Expanded backend unit/API tests and release preflight coverage.
- Android build status remains unchanged: Gradle/Android SDK compilation and device testing are still required.


## V16.7 — 2026-10-20
- Added starter Android string resource sets for the 15 approved languages. This is a localization scaffold; Compose UI integration and full translation remain pending. See `LOCALIZATION_PLAN_V16_7.md`.

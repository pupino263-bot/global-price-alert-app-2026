# Global Price Alert — localization integration V16.8

Scope: localization only. Product/search/monetization logic intentionally unchanged.

- Added AppCompat per-app locale support and persistent language selection for the 15 approved locales.
- Added a language selector entry in the existing top controls.
- Expanded Android string resources for the main search, account, notification, alert and Premium interface.
- Added locale persistence metadata.
- Android build/device tests still need to be run in an environment with JDK, Gradle and Android SDK.
- Translation completeness and native-language review remain required before public release; some less common long messages use Italian fallback pending full translation review.
- This archive is source code, not an APK/AAB.

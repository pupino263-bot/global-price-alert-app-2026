# Global Price Alert — Build Gate Report V16.5

**Data:** 19 ottobre 2026  
**Base verificata:** V16.4 Smart Matching / Smart Compatibility

## Verifiche rieseguite in estrazione pulita

- `npm test --prefix backend`: PASS (5 gruppi di test).
- `node scripts/release-preflight.mjs`: PASS prima delle modifiche al gate.
- `node --check` su backend e scripts: PASS da ripetere dopo la modifica del preflight.
- Integrità ZIP V16.4: PASS secondo il manifest della versione di base.

## Migliorie aggiunte in V16.5

1. Workflow GitHub Actions avviabile anche manualmente (`workflow_dispatch`), oltre che su push e pull request.
2. Script PowerShell `scripts/build-android-windows.ps1`: esegue `clean assembleDebug`, verifica la presenza dell'APK e stampa SHA-256.
3. Release preflight aggiornato per richiedere lo script Windows e la possibilità di avvio manuale del workflow.

## Stato reale del gate Android

**NON ANCORA SUPERATO.** In questo ambiente sono presenti Java 21 e Node 22, ma non Gradle, Android SDK o variabili `ANDROID_HOME` / `ANDROID_SDK_ROOT`. Non è stato generato alcun APK/AAB.

Il repository GitHub accessibile all'account collegato ha restituito zero repository. Per eseguire la build remota serve caricare il pacchetto in un repository GitHub e avviare Actions. Nessuna credenziale o segreto è stato richiesto o incorporato nel pacchetto.

## Prossimo passaggio operativo

- Se si usa GitHub: caricare il contenuto della cartella `gpa_work` come radice del repository, quindi aprire **Actions → Global Price Alert CI → Run workflow**. Al termine scaricare l'artefatto `global-price-alert-debug-apk`.
- Se si usa Windows: estrarre il pacchetto, aprire PowerShell nella cartella del progetto, eseguire prima `scripts/bootstrap-android-windows.ps1` e poi `scripts/build-android-windows.ps1`. Il setup scarica SDK e Gradle e richiede una connessione Internet.
- Dopo aver ottenuto l'APK: installazione su dispositivo reale, test rete/API, e solo dopo configurazione backend HTTPS di produzione e build release/AAB firmata.

## Fuori da questo gate

Non sono ancora certificati: provider live eBay, PostgreSQL pubblico, notifiche push, Google Play Billing, pubblicità, postback affiliate, policy e listing Play Store, né pubblicazione. Il debug APK non è un pacchetto pubblicabile.

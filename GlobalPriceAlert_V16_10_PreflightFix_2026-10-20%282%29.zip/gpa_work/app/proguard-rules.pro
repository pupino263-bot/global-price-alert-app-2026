# Global Price Alert release rules

package com.globalpricealert.app

data class ProductOffer(
    val id: String,
    val title: String,
    val brand: String,
    val category: String,
    val store: String,
    val price: Double,
    val shipping: Double,
    val availability: String,
    val compatibility: String? = null,
    val url: String = "",
    val mandatoryFees: Double = 0.0,
    val discount: Double = 0.0,
    val currency: String = "EUR",
    val sourceId: String = store,
    val productKey: String = "",
    val taxes: Double = 0.0,
    val costIsEstimate: Boolean = false
) {
    val effectiveCost: Double get() = EffectiveCost.calculate(price, shipping, mandatoryFees, discount, taxes)
}

data class PriceAlert(val productId: String, val targetPrice: Double, val query: String = "", val category: String = "Tutte", val countryCode: String = "IT")

data class SearchState(
    val query: String = "",
    val selectedCategory: String = "Tutte",
    val offers: List<ProductOffer> = emptyList(),
    val alerts: List<PriceAlert> = emptyList(),
    val premium: Boolean = false,
    val premiumVerified: Boolean = false,
    val searched: Boolean = false,
    val demoFallback: Boolean = false,
    val liveSearchAvailable: Boolean = false,
    val statusMessage: String = ""
)

object Catalog {
    val categories = CategoryTaxonomy.topLevelNames

    val offers = listOf(
        ProductOffer("phone-001", "Smartphone 256 GB", "DemoBrand", "Elettronica e telefonia", "Store A", 499.0, 0.0, "Disponibile"),
        ProductOffer("phone-001", "Smartphone 256 GB", "DemoBrand", "Elettronica e telefonia", "Store B", 479.0, 6.90, "Disponibile"),
        ProductOffer("helmet-001", "Casco moto integrale", "MotoSafe", "Auto e moto", "Store C", 139.0, 9.90, "Disponibile"),
        ProductOffer("filter-001", "Filtro aria ricambio", "MotoSafe", "Auto e moto", "Store D", 24.90, 5.90, "Compatibile con modello selezionato", "Compatibile"),
        ProductOffer("chair-001", "Sedia ergonomica", "WorkPro", "Casa e arredamento", "Store E", 189.0, 0.0, "Disponibile")
    )
}

object SmartMatching {
    fun search(query: String, category: String): List<ProductOffer> {
        val q = query.trim().lowercase()
        return Catalog.offers
            .filter { category == "Tutte" || it.category == category }
            .filter { q.isBlank() || listOf(it.title, it.brand, it.category, it.store, it.compatibility.orEmpty()).any { v -> v.lowercase().contains(q) } }
            .sortedWith(compareBy<ProductOffer> { it.effectiveCost }.thenByDescending { SmartCompatibility.score(q, it.compatibility) })
    }
}


data class PriceNotification(
    val id: String,
    val type: String,
    val productKey: String,
    val effectiveCost: Double,
    val currency: String,
    val createdAt: String,
    val read: Boolean
)

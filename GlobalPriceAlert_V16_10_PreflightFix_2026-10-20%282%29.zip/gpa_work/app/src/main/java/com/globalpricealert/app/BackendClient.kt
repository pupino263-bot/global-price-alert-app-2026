package com.globalpricealert.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Dependency-free HTTP client. Release builds must provide a real HTTPS backend URL. */
class BackendClient(private val baseUrl: String, context: Context) {
    private val sessionVault = SessionVault(context.applicationContext)
    @Volatile private var token: String? = sessionVault.load()
    @Volatile var lastSearchHadLiveSource: Boolean = false
        private set
    val isAuthenticated: Boolean get() = !token.isNullOrBlank()

    fun register(email: String, password: String): Boolean = request("POST", "/v1/auth/register", JSONObject().apply {
        put("email", email); put("password", password)
    }) != null

    fun registerAndLogin(email: String, password: String): Boolean {
        // If registration reports a conflict, still attempt login so existing users can use this flow.
        register(email, password)
        return login(email, password)
    }

    fun login(email: String, password: String): Boolean {
        val response = request("POST", "/v1/auth/login", JSONObject().apply {
            put("email", email); put("password", password)
        }) ?: return false
        token = JSONObject(response).optString("token").takeIf { it.isNotBlank() }
        sessionVault.save(token)
        return token != null
    }

    fun hasConfiguredSources(): Boolean {
        val response = request("GET", "/v1/sources") ?: return false
        return JSONObject(response).optBoolean("sourcesConfigured", JSONObject(response).optBoolean("liveSearchAvailable", false))
    }

    fun logout(): Boolean {
        val ok = request("POST", "/v1/auth/logout", JSONObject()) != null
        // Clear the local credential even when the server is temporarily unreachable.
        token = null
        sessionVault.clear()
        return ok
    }

    fun deleteAccount(): Boolean {
        val ok = request("DELETE", "/v1/me") != null
        if (ok) {
            token = null
            sessionVault.clear()
        }
        return ok
    }

    fun notifications(): List<PriceNotification> {
        val response = request("GET", "/v1/notifications") ?: return emptyList()
        val rows = JSONObject(response).optJSONArray("notifications") ?: JSONArray()
        return buildList {
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                add(PriceNotification(
                    id = row.optString("id"),
                    type = row.optString("type", "NOTICE"),
                    productKey = row.optString("productKey"),
                    effectiveCost = row.optDouble("effectiveCost", Double.NaN),
                    currency = row.optString("currency", "EUR"),
                    createdAt = row.optString("createdAt"),
                    read = !row.isNull("readAt") && row.optString("readAt").isNotBlank()
                ))
            }
        }
    }

    fun markNotificationRead(id: String): Boolean =
        request("POST", "/v1/notifications/$id/read", JSONObject()) != null

    fun search(query: String, category: String, countryCode: String = "IT"): List<ProductOffer> {
        val response = request("POST", "/v1/search", JSONObject().apply {
            put("query", query); put("category", category); put("countryCode", countryCode); put("currency", "EUR"); put("maxResults", 50)
        }) ?: run { lastSearchHadLiveSource = false; return emptyList() }
        val payload = JSONObject(response)
        lastSearchHadLiveSource = payload.optBoolean("liveSearchAvailable", false)
        val out = mutableListOf<ProductOffer>()
        val arr = payload.optJSONArray("offers") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val store = o.optString("store", o.optString("sourceId"))
            out += ProductOffer(
                o.optString("id"), o.optString("title"), o.optString("brand"), o.optString("category"), store,
                o.optDouble("price"), o.optDouble("shipping"), o.optString("availability", "Disponibilità da verificare"),
                o.optString("compatibility").takeIf { it.isNotBlank() }, o.optString("url"),
                o.optDouble("mandatoryFees"), o.optDouble("discount"), o.optString("currency", "EUR"),
                o.optString("sourceId", store), o.optString("normalizedProductKey"),
                o.optDouble("taxes"), o.optBoolean("costIsEstimate", false)
            )
        }
        return out
    }

    fun createAlert(productKey: String, targetPrice: Double, query: String, category: String, countryCode: String = "IT"): Boolean = request("POST", "/v1/alerts", JSONObject().apply {
        put("productKey", productKey); put("targetPrice", targetPrice); put("currency", "EUR")
        put("query", query); put("category", category); put("countryCode", countryCode)
    }) != null

    private fun request(method: String, path: String, body: JSONObject? = null): String? {
        if (baseUrl.isBlank()) return null
        return runCatching {
            val c = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method; connectTimeout = 7000; readTimeout = 7000
                setRequestProperty("Accept", "application/json")
                token?.let { setRequestProperty("Authorization", "Bearer $it") }
                if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
            }
            try {
                if (body != null) c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                if (code == HttpURLConnection.HTTP_UNAUTHORIZED && token != null) {
                    token = null
                    sessionVault.clear()
                }
                if (code !in 200..299) null else text
            } finally { c.disconnect() }
        }.getOrNull()
    }
}

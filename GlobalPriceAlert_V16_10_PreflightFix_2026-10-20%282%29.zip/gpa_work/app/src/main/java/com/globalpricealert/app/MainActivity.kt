package com.globalpricealert.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlobalPriceAlertApp() }
    }
}

@Composable
fun GlobalPriceAlertApp() {
    var state by remember { mutableStateOf(SearchState()) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Tutte") }
    var showPremium by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var showAccount by remember { mutableStateOf(false) }
    var showDeleteAccount by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }
    var notifications by remember { mutableStateOf(emptyList<PriceNotification>()) }
    var notificationsBusy by remember { mutableStateOf(false) }
    var accountEmail by remember { mutableStateOf("") }
    var accountPassword by remember { mutableStateOf("") }
    var accountMessage by remember { mutableStateOf("") }
    var accountBusy by remember { mutableStateOf(false) }
    var pendingAlert by remember { mutableStateOf<PriceAlert?>(null) }
    val context = LocalContext.current
    val appContext = context.applicationContext
    val backend = remember(appContext) { BackendClient(BuildConfig.BACKEND_URL, appContext) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val activity = context as? ComponentActivity

    fun finishAuthentication(register: Boolean) {
        if (accountEmail.isBlank() || accountPassword.length < 8) {
            accountMessage = context.getString(R.string.email_password_error)
            return
        }
        accountBusy = true
        accountMessage = context.getString(R.string.checking_account)
        executor.execute {
            val ok = if (register) backend.registerAndLogin(accountEmail.trim(), accountPassword) else backend.login(accountEmail.trim(), accountPassword)
            activity?.runOnUiThread {
                accountBusy = false
                if (ok) {
                    showAccount = false
                    accountMessage = context.getString(R.string.login_success)
                    val pending = pendingAlert
                    pendingAlert = null
                    if (pending != null) {
                        executor.execute {
                            val created = backend.createAlert(pending.productId, pending.targetPrice, pending.query, pending.category, pending.countryCode)
                            activity?.runOnUiThread {
                                if (created) state = state.copy(alerts = (state.alerts + pending).distinctBy { it.productId })
                                else accountMessage = context.getString(R.string.alert_save_error)
                            }
                        }
                    }
                } else {
                    accountMessage = context.getString(R.string.login_error)
                }
            }
        }
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Global Price Alert", style = MaterialTheme.typography.headlineMedium)
                    Text(stringResource(R.string.app_tagline))
                }
                Column {
                    TextButton(onClick = {
                        if (!backend.isAuthenticated) {
                            accountMessage = stringResource(R.string.notifications_account_required)
                            showAccount = true
                        } else {
                            showNotifications = true
                            notificationsBusy = true
                            executor.execute {
                                val result = backend.notifications()
                                activity?.runOnUiThread {
                                    notifications = result
                                    notificationsBusy = false
                                }
                            }
                        }
                    }) { Text(stringResource(R.string.notifications)) }
                    TextButton(onClick = { showAccount = true }) { Text(if (backend.isAuthenticated) stringResource(R.string.account) else stringResource(R.string.sign_in)) }
                    TextButton(onClick = { showPremium = true }) { Text(if (state.premiumVerified) stringResource(R.string.premium_active) else stringResource(R.string.premium)) }
                    TextButton(onClick = { showLanguage = true }) { Text(stringResource(R.string.language_setting)) }
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(stringResource(R.string.search_hint)) }
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategorySelector(category) { category = it }
                Button(onClick = {
                    val local = SmartMatching.search(query, category)
                    state = state.copy(query = query, selectedCategory = category, offers = local, searched = true,
                        demoFallback = true, liveSearchAvailable = false, statusMessage = stringResource(R.string.searching_sources))
                    executor.execute {
                        val remote = backend.search(query, category)
                        val live = backend.lastSearchHadLiveSource
                        activity?.runOnUiThread {
                            state = if (live) {
                                state.copy(offers = remote, demoFallback = false, liveSearchAvailable = true,
                                    statusMessage = if (remote.isEmpty()) stringResource(R.string.no_online_results) else stringResource(R.string.online_results))
                            } else {
                                state.copy(offers = local, demoFallback = true, liveSearchAvailable = false,
                                    statusMessage = stringResource(R.string.demo_mode))
                            }
                        }
                    }
                }) { Text(stringResource(R.string.search)) }
            }
            if (state.statusMessage.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(state.statusMessage, style = MaterialTheme.typography.bodySmall)
            }
            if (!showAccount && accountMessage.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(accountMessage, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(10.dp))
            if (state.searched) {
                Text(stringResource(R.string.offer_count, state.offers.size), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(state.offers) { offer ->
                    val productKey = offer.productKey.ifBlank { offer.id }
                    OfferCard(offer, state.alerts.any { it.productId == productKey }, onAlert = { target ->
                        val alert = PriceAlert(productKey, target, offer.title, offer.category, "IT")
                        if (!backend.isAuthenticated) {
                            pendingAlert = alert
                            accountMessage = stringResource(R.string.alert_account_required)
                            showAccount = true
                        } else {
                            executor.execute {
                                val created = backend.createAlert(productKey, target, offer.title, offer.category, "IT")
                                activity?.runOnUiThread {
                                    if (created) state = state.copy(alerts = (state.alerts + alert).distinctBy { it.productId })
                                    else accountMessage = stringResource(R.string.alert_save_failed)
                                }
                            }
                        }
                    })
                }
            }
        }

        if (showLanguage) {
            val languageOptions = listOf(
                "it" to "Italiano", "en" to "English", "es" to "Español", "fr" to "Français", "de" to "Deutsch",
                "pt" to "Português", "zh-CN" to "简体中文", "ja" to "日本語", "ar" to "العربية", "hi" to "हिन्दी",
                "ko" to "한국어", "nl" to "Nederlands", "ru" to "Русский", "pl" to "Polski", "tr" to "Türkçe"
            )
            AlertDialog(
                onDismissRequest = { showLanguage = false },
                title = { Text(stringResource(R.string.choose_language)) },
                text = {
                    LazyColumn(Modifier.heightIn(max = 440.dp)) {
                        items(languageOptions) { option ->
                            TextButton(onClick = {
                                androidx.appcompat.app.AppCompatDelegate.setApplicationLocales(
                                    androidx.core.os.LocaleListCompat.forLanguageTags(option.first)
                                )
                                showLanguage = false
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text(option.second, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showLanguage = false }) { Text(stringResource(R.string.close)) } }
            )
        }

        if (showAccount) {
            AlertDialog(
                onDismissRequest = { if (!accountBusy) showAccount = false },
                title = { Text(stringResource(R.string.account_title)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (backend.isAuthenticated) {
                            Text(stringResource(R.string.session_encrypted))
                            TextButton(onClick = { showDeleteAccount = true }) { Text(stringResource(R.string.delete_account_data)) }
                        } else {
                            OutlinedTextField(value = accountEmail, onValueChange = { accountEmail = it }, label = { Text(stringResource(R.string.email)) }, singleLine = true)
                            OutlinedTextField(value = accountPassword, onValueChange = { accountPassword = it }, label = { Text(stringResource(R.string.password_hint)) }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        }
                        if (accountMessage.isNotBlank()) Text(accountMessage, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    if (backend.isAuthenticated) {
                        TextButton(enabled = !accountBusy, onClick = {
                            accountBusy = true
                            executor.execute {
                                val ok = backend.logout()
                                activity?.runOnUiThread {
                                    accountBusy = false
                                    showAccount = false
                                    accountMessage = if (ok) context.getString(R.string.logout_success) else context.getString(R.string.logout_error)
                                }
                            }
                        }) { Text(if (accountBusy) stringResource(R.string.wait) else stringResource(R.string.logout)) }
                    } else {
                        Button(enabled = !accountBusy, onClick = { finishAuthentication(false) }) { Text(if (accountBusy) stringResource(R.string.wait) else stringResource(R.string.sign_in)) }
                    }
                },
                dismissButton = {
                    if (backend.isAuthenticated) {
                        TextButton(enabled = !accountBusy, onClick = { showAccount = false }) { Text(stringResource(R.string.close)) }
                    } else {
                        Row {
                            TextButton(enabled = !accountBusy, onClick = { finishAuthentication(true) }) { Text(stringResource(R.string.create_account)) }
                            TextButton(enabled = !accountBusy, onClick = { showAccount = false }) { Text(stringResource(R.string.close)) }
                        }
                    }
                }
            )
        }

        if (showNotifications) {
            AlertDialog(
                onDismissRequest = { showNotifications = false },
                title = { Text(stringResource(R.string.price_notifications)) },
                text = {
                    when {
                        notificationsBusy -> Text(stringResource(R.string.loading_notifications))
                        notifications.isEmpty() -> Text(stringResource(R.string.empty_notifications))
                        else -> LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(notifications, key = { it.id }) { notice ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(if (notice.type == "PRICE_DROP") stringResource(R.string.price_target_reached) else notice.type, style = MaterialTheme.typography.titleSmall)
                                        if (notice.effectiveCost.isFinite()) {
                                            Text(stringResource(R.string.observed_cost, notice.effectiveCost.toCurrency(notice.currency)))
                                        }
                                        if (notice.productKey.isNotBlank()) Text(stringResource(R.string.product, notice.productKey), style = MaterialTheme.typography.bodySmall)
                                        Text(if (notice.read) stringResource(R.string.read) else stringResource(R.string.unread), style = MaterialTheme.typography.bodySmall)
                                        if (!notice.read) TextButton(onClick = {
                                            executor.execute {
                                                val ok = backend.markNotificationRead(notice.id)
                                                if (ok) {
                                                    val refreshed = backend.notifications()
                                                    activity?.runOnUiThread { notifications = refreshed }
                                                }
                                            }
                                        }) { Text(stringResource(R.string.mark_read)) }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showNotifications = false }) { Text(stringResource(R.string.close)) } },
                dismissButton = { TextButton(onClick = {
                    notificationsBusy = true
                    executor.execute {
                        val result = backend.notifications()
                        activity?.runOnUiThread { notifications = result; notificationsBusy = false }
                    }
                }) { Text(stringResource(R.string.refresh)) } }
            )
        }

        if (showDeleteAccount) {
            AlertDialog(
                onDismissRequest = { if (!accountBusy) showDeleteAccount = false },
                title = { Text(stringResource(R.string.delete_account_title)) },
                text = { Text(stringResource(R.string.delete_account_message)) },
                confirmButton = { Button(enabled = !accountBusy, onClick = {
                    accountBusy = true
                    executor.execute {
                        val deleted = backend.deleteAccount()
                        activity?.runOnUiThread {
                            accountBusy = false
                            showDeleteAccount = false
                            showAccount = false
                            accountMessage = if (deleted) context.getString(R.string.account_deleted) else context.getString(R.string.delete_account_error)
                        }
                    }
                }) { Text(if (accountBusy) stringResource(R.string.wait) else stringResource(R.string.delete_permanently)) } },
                dismissButton = { TextButton(enabled = !accountBusy, onClick = { showDeleteAccount = false }) { Text(stringResource(R.string.cancel)) } }
            )
        }

        if (showPremium) {
            AlertDialog(
                onDismissRequest = { showPremium = false },
                title = { Text(stringResource(R.string.premium)) },
                text = { Text(stringResource(R.string.premium_message)) },
                confirmButton = { Button(onClick = { showPremium = false }) { Text(stringResource(R.string.close)) } }
            )
        }
    }
}

@Composable
private fun CategorySelector(selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text(selected) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Catalog.categories.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { onSelected(item); expanded = false }) }
        }
    }
}

@Composable
private fun OfferCard(offer: ProductOffer, hasAlert: Boolean, onAlert: (Double) -> Unit) {
    var alertOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(offer.title, style = MaterialTheme.typography.titleMedium)
            Text("${offer.brand} • ${offer.category}")
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.price, offer.price.toCurrency(offer.currency), offer.shipping.toCurrency(offer.currency)))
            if (offer.mandatoryFees > 0 || offer.discount > 0) {
                Text(stringResource(R.string.mandatory_discount, offer.mandatoryFees.toCurrency(offer.currency), offer.discount.toCurrency(offer.currency)))
            }
            Text(stringResource(R.string.effective_cost, if (offer.costIsEstimate) stringResource(R.string.estimated) else "", offer.effectiveCost.toCurrency(offer.currency)), style = MaterialTheme.typography.titleSmall)
            if (offer.costIsEstimate) {
                Text(stringResource(R.string.alert_cost_incomplete), style = MaterialTheme.typography.bodySmall)
            }
            Text(stringResource(R.string.store_availability, offer.store, offer.availability))
            offer.compatibility?.let { Text(stringResource(R.string.compatibility, it)) }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !offer.costIsEstimate && offer.effectiveCost.isFinite() && offer.effectiveCost > 0.0,
                    onClick = { alertOpen = true }
                ) {
                    Text(
                        when {
                            hasAlert -> stringResource(R.string.alert_active)
                            offer.costIsEstimate -> stringResource(R.string.cost_to_verify)
                            else -> stringResource(R.string.alert_if_drops)
                        }
                    )
                }
                if (offer.url.startsWith("https://") || offer.url.startsWith("http://")) {
                    TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(offer.url))) } }) { Text(stringResource(R.string.open_store)) }
                }
            }
        }
    }
    if (alertOpen) {
        AlertDialog(
            onDismissRequest = { alertOpen = false },
            title = { Text(stringResource(R.string.set_alert)) },
            text = { Text(stringResource(R.string.alert_associated, offer.title)) },
            confirmButton = { Button(onClick = { onAlert(offer.effectiveCost * 0.9); alertOpen = false }) { Text(stringResource(R.string.set_minus_10)) } },
            dismissButton = { TextButton(onClick = { alertOpen = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

private fun Double.toCurrency(currency: String = "EUR"): String = String.format(Locale.ITALY, "%.2f %s", this, currency)

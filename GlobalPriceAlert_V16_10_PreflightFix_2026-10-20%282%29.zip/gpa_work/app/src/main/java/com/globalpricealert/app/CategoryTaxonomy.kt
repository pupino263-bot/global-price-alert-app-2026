package com.globalpricealert.app

/** Master taxonomy: intentionally detailed; new products inherit accessories, spares, consumables and compatible items. */
data class CategoryNode(val name: String, val children: List<String>)

object CategoryTaxonomy {
    private val commonSubcategories = listOf("Accessori e complementi", "Componenti e ricambi", "Consumabili", "Prodotti compatibili", "Varianti professionali e specialistiche")

    private val baseNodes = listOf(
        CategoryNode("Elettronica e telefonia", listOf("Smartphone", "Tablet", "Computer", "Componenti PC", "Monitor", "Audio", "TV", "Fotografia", "Accessori", "Caricatori e cavi", "Ricambi")),
        CategoryNode("Casa e arredamento", listOf("Mobili", "Cucina", "Bagno", "Illuminazione", "Materassi", "Tessili", "Finestre e porte", "Zanzariere", "Bambù e materiali", "Accessori e ricambi")),
        CategoryNode("Elettrodomestici", listOf("Frigoriferi", "Lavatrici", "Lavastoviglie", "Forni", "Piccoli elettrodomestici", "Aspirazione", "Climatizzazione", "Ricambi e consumabili")),
        CategoryNode("Auto e moto", listOf("Auto", "Moto", "Scooter", "Caschi", "Abbigliamento", "Accessori", "Pneumatici", "Ricambi", "Motori rigenerati", "Diagnostica", "Lubrificanti", "Carrozzeria")),
        CategoryNode("Mobilità e rider", listOf("Borse termiche", "Porta smartphone", "Supporti", "Abbigliamento", "Sicurezza", "Accessori scooter", "Ricambi")),
        CategoryNode("Utensili e ferramenta", listOf("Utensili manuali", "Elettroutensili", "Compressori", "Saldatura", "Ferramenta", "Viteria", "Magneti", "Strumenti di precisione", "Ricambi", "Consumabili")),
        CategoryNode("Edilizia e ristrutturazione", listOf("Cartongesso", "Resine", "Profili metallici", "Travi in legno", "Idraulica", "Elettrico", "Pittura", "Serramenti", "Sicurezza cantiere", "Macchinari")),
        CategoryNode("Tessile e produzione abbigliamento", listOf("Macchine da cucire industriali", "Tagliacuci", "Coverstitch", "Ricamatrici", "Taglio tessuti", "Presse", "Stampa e transfer", "Confezionamento", "Accessori e ricambi")),
        CategoryNode("Moda e abbigliamento", listOf("Donna", "Uomo", "Bambini", "Intimo", "Scarpe", "Borse", "Pelletteria", "Surfwear", "Accessori", "Merceria")),
        CategoryNode("Bellezza e cura personale", listOf("Cosmetici", "Make-up", "Profumi", "Capelli", "Parrucchiere", "Estetica", "Attrezzatura professionale", "Consumabili")),
        CategoryNode("Sport e fitness", listOf("Fitness", "Crossfit", "Running", "Ciclismo", "Calcio", "Sport acquatici", "Surf", "Arrampicata", "Trekking", "Attrezzatura professionale")),
        CategoryNode("Outdoor e avventura", listOf("Camping", "Trekking", "Pesca", "Caccia", "Parapendio", "Paracadutismo", "Volo libero", "Speleologia", "Accessori e ricambi")),
        CategoryNode("Animali", listOf("Cani", "Gatti", "Pesci", "Uccelli", "Piccoli animali", "Mangimi", "Igiene", "Accessori", "Veterinaria non prescrittiva")),
        CategoryNode("Salute e ausili", listOf("Mobilità", "Ortopedia", "Ausili", "Poltrone e letti", "Attrezzatura professionale", "Consumabili")),
        CategoryNode("Laboratorio e scientifico", listOf("Strumentazione", "Microscopia", "Misura", "Chimica", "Consumabili", "Ricambi", "Sicurezza")),
        CategoryNode("Dentale e medicale professionale", listOf("Poltrone", "Strumentazione", "Aspirazione", "Sterilizzazione", "Consumabili", "Ricambi")),
        CategoryNode("Agricoltura", listOf("Macchine agricole", "Attrezzature", "Irrigazione", "Serre", "Ricambi", "Consumabili")),
        CategoryNode("Piscine e benessere", listOf("Piscine", "Pompe", "Filtri", "Riscaldamento", "Prodotti trattamento", "Accessori", "Ricambi")),
        CategoryNode("Ufficio e scuola", listOf("Cancelleria", "Stampanti", "Arredo ufficio", "Carta", "Scuola", "Materiale professionale")),
        CategoryNode("Libri, arte e collezionismo", listOf("Libri", "Antiquariato", "Arte", "Orologeria", "Componenti orologi", "Collezionismo")),
        CategoryNode("Videogiochi", listOf("Console", "Giochi", "PC gaming", "Accessori", "Ricambi")),
        CategoryNode("Pulizia e detergenza", listOf("Detersivi", "Igiene casa", "Igiene personale", "Attrezzatura professionale", "Consumabili")),
        CategoryNode("Sicurezza e antincendio", listOf("Allarmi", "Videosorveglianza", "Controllo accessi", "Antincendio", "DPI", "Ricambi")),
        CategoryNode("Logistica e magazzino", listOf("Scaffalature", "Contenitori", "Imballaggio", "Pallet", "Movimentazione", "Etichettatura", "Attrezzature")),
        CategoryNode("Viaggi e servizi", listOf("Hotel", "Tour", "Pacchetti", "Trasporti", "Attività", "Servizi professionali")),
        CategoryNode("Immobiliare", listOf("Vendita", "Affitto", "Commerciale", "Terreni", "Capannoni")),
        CategoryNode("Alimentari e bevande", listOf("Spesa", "Specialità", "Vini e bevande", "Conserve", "Professionale", "Confezioni e multipack")),
        CategoryNode("Fumatori e accessori", listOf("Dispositivi per svapo", "Sigarette elettroniche", "Pod e atomizzatori", "Resistenze e coil", "Batterie e caricabatterie", "Ricambi e consumabili", "Accessori compatibili")),
        CategoryNode("Gioielli e bigiotteria", listOf("Gioielli", "Bigiotteria", "Perle e pietre", "Strass e cristalli", "Minuteria e chiusure", "Attrezzatura per gioielleria", "Confezioni e espositori")),
        CategoryNode("Artigianato, filati e merceria", listOf("Filati e cordini", "Uncinetto e ferri", "Filati per borse", "Strass e decorazioni", "Tessuti e fodere", "Accessori per borse", "Macchine da cucire artigianali", "Materiali creativi", "Kit fai-da-te")),
        CategoryNode("Tatuaggi e body art", listOf("Macchinette e alimentatori", "Aghi e cartucce", "Inchiostri e pigmenti", "Grip e impugnature", "Stencil e trasferimento", "Igiene e monouso", "Arredi e lettini", "Ricambi e consumabili")),
        CategoryNode("Integratori e nutrizione sportiva", listOf("Proteine", "Vitamine e minerali", "Nutrizione sportiva", "Alimenti funzionali", "Shaker e accessori", "Confezioni e multipack", "Attrezzatura professionale")),
        CategoryNode("Riscaldamento, climatizzazione ed energia", listOf("Caldaie", "Stufe e camini", "Pompe di calore", "Condizionatori", "Ventilazione", "Termostati e controlli", "Fotovoltaico", "Accumulo e inverter", "Ricambi e filtri")),
        CategoryNode("Domotica, reti e automazione", listOf("Smart home", "Sensori e attuatori", "Router e reti", "Cablaggio", "Controllori e PLC", "Motori e azionamenti", "Robotica", "Ricambi e moduli compatibili")),
        CategoryNode("Macchinari e impianti industriali", listOf("Macchine utensili", "Macchine tessili industriali", "Taglio e lavorazione", "Presse industriali", "Stampa industriale", "Confezionamento e imballaggio", "Trasmissioni e motori", "Pneumatica e oleodinamica", "Ricambi e consumabili")),
        CategoryNode("Idraulica e trattamento acqua", listOf("Rubinetteria", "Tubi e raccordi", "Pompe", "Filtri e addolcitori", "Depurazione", "Valvole", "Riscaldamento idraulico", "Ricambi e guarnizioni")),
        CategoryNode("Software e servizi digitali", listOf("Software e licenze", "Servizi cloud", "Hosting e domini", "VPN e sicurezza digitale", "Strumenti professionali", "Abbonamenti digitali", "Servizi online"))
    )

    // Cross-cutting branches are inherited by every category, retroactively, without duplicating labels.
    val nodes: List<CategoryNode> = baseNodes.map { node ->
        node.copy(children = (node.children + commonSubcategories).distinctBy { it.trim().lowercase() })
    }
    val topLevelNames: List<String> = listOf("Tutte") + nodes.map { it.name }
    fun subcategories(category: String): List<String> = nodes.firstOrNull { it.name == category }?.children.orEmpty()
}

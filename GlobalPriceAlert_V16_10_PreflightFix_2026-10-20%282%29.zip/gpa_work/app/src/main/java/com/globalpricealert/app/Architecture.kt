package com.globalpricealert.app

/** Contracts for replacing demo sources with authorized store/API adapters. */
interface ProductSource {
    val id: String
    suspend fun search(request: SearchRequest): List<ProductOffer>
}

data class SearchRequest(
    val query: String,
    val category: String = "Tutte",
    val countryCode: String = "IT",
    val currency: String = "EUR",
    val maxResults: Int = 50
)

data class NormalizedOffer(
    val offer: ProductOffer,
    val sourceId: String,
    val normalizedProductKey: String,
    val affiliateUrl: String? = null
)

object EffectiveCost {
    fun calculate(price: Double, shipping: Double, mandatoryFees: Double = 0.0, discount: Double = 0.0, taxes: Double = 0.0): Double =
        (price + shipping + mandatoryFees + taxes - discount).coerceAtLeast(0.0)
}

object SmartCompatibility {
    fun score(query: String, compatibility: String?): Int {
        if (compatibility.isNullOrBlank() || query.isBlank()) return 0
        val q = query.lowercase().split(Regex("\\W+")).filter { it.length >= 2 }.toSet()
        val c = compatibility.lowercase()
        return q.count { c.contains(it) } * 25
    }
}

object AffiliateTracker {
    fun buildClickId(sourceId: String, productId: String): String =
        "${sourceId}_${productId}_${java.util.UUID.randomUUID()}"
}

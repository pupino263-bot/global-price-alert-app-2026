plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val configuredBackendUrl = (providers.gradleProperty("gpaBackendUrl").orNull ?: System.getenv("GPA_BACKEND_URL"))?.takeIf { it.isNotBlank() }
val debugBackendUrl = configuredBackendUrl ?: "http://10.0.2.2:8787"
val releaseBackendUrl = configuredBackendUrl ?: ""

android {
    namespace = "com.globalpricealert.app"
    compileSdk = 36
    buildFeatures {
        buildConfig = true
        compose = true
    }

    defaultConfig {
        applicationId = "com.globalpricealert.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        debug {
            buildConfigField("String", "BACKEND_URL", "\"${debugBackendUrl}\"")
        }
        release {
            isMinifyEnabled = false
            buildConfigField("String", "BACKEND_URL", "\"${releaseBackendUrl}\"")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

tasks.matching { it.name == "preReleaseBuild" }.configureEach {
    doFirst {
        if (releaseBackendUrl.isBlank() || !releaseBackendUrl.startsWith("https://")) {
            throw GradleException("Set GPA_BACKEND_URL (or -PgpaBackendUrl) to the real HTTPS production backend before building release.")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation(platform("androidx.compose:compose-bom:2025.04.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
}

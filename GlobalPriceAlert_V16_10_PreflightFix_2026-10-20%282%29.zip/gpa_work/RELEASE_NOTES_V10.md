# Global Price Alert V10 — release engineering

## What changed
- Android CI explicitly provisions Android SDK platform 36 and build-tools 36.0.0.
- CI uploads the compiled debug APK as an artifact for installation and manual regression.
- Existing backend tests remain part of the same workflow.

## What this does not mean
- A successful debug build is not a Play Store release.
- No release signing key, production backend, live marketplace credentials, Play Billing, ad SDK, affiliate postbacks, or FCM delivery is configured by this change.
- The workflow has been updated in the source tree but has not run on GitHub in this session.

## Verification in this session
- `npm test` in `backend/`: PASS, all four test groups.
- ZIP integrity: checked after packaging.
- Full Android Gradle build: NOT RUN; Android SDK and Gradle executable/wrapper are absent from this environment.

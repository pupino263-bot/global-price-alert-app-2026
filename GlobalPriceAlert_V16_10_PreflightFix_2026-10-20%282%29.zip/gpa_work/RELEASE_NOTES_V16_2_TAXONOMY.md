# Release notes — V16.2 taxonomy coverage

Date: 17 October 2026

## Changed
- Added nine first-level categories: jewellery/costume jewellery; crafts/yarn/haberdashery; tattoo/body-art supplies; sports nutrition; heating/cooling/energy; smart-home/networks/automation; industrial machinery/plants; plumbing/water treatment; software/digital services.
- Existing shared branches remain inherited by every category: accessories/complements, components/spares, consumables, compatible products, and professional/specialist variants.
- Strengthened the static release preflight to enforce a minimum count of first-level categories, uniqueness of category names, and presence of the nine new categories.
- Corrected the README package version label from V15 to V16.1 source package and recorded current verification boundaries.

## Verification
- `node scripts/release-preflight.mjs`: PASS.
- `cd backend && npm test`: PASS (source normalization/failure isolation, mocked eBay adapter, alert monitoring, API validation/history/notifications/affiliate/account deletion).
- `kotlinc Domain.kt CategoryTaxonomy.kt Architecture.kt`: PASS.
- Android XML parsing: PASS (3 XML files).
- Android Gradle build: NOT RUN. SDK/Gradle downloads failed because this environment could not resolve `dl.google.com` and `services.gradle.org`.

This release note does not claim APK/AAB generation, live marketplace access, live PostgreSQL validation, billing, push, ads, or Play Store publication.

# Global Price Alert — stato verifiche locali (13 ottobre 2026)

## Esito

- Archivio V16 originale: controllo CRC ZIP superato.
- Preflight statico `node scripts/release-preflight.mjs`: PASS (16 file richiesti e guardrail controllati).
- Test backend `npm test`: PASS per normalizzazione fonti, adapter eBay mock, monitoraggio avvisi e test API/integrati.
- Sintassi Node (`node --check` su script, sorgenti e test): PASS.
- Sintassi shell (`bash -n` sui due script Linux): PASS.
- XML Android: PASS (3 file XML analizzati).
- Build Android `assembleDebug`: NON ESEGUITA. Il bootstrap non è riuscito perché l'ambiente non risolve `dl.google.com` (`curl: (6) Could not resolve host`). Android SDK e distribuzione Gradle non risultano installati nella cartella di lavoro.

## Cosa questo NON dimostra

Non è stato prodotto né verificato un APK/AAB; non sono stati eseguiti test su dispositivo, test end-to-end con servizi remoti, verifica di credenziali/integrazioni live o validazione Play Console. Il preflight statico e i test backend non sostituiscono una build Android reale.

## Prossimo passo necessario

Eseguire `scripts/bootstrap-android-linux.sh` in un ambiente con accesso DNS/rete ai repository Android e Gradle, poi `scripts/build-android-linux.sh`; verificare l'APK risultante `app/build/outputs/apk/debug/app-debug.apk` e installarlo su un dispositivo Android.

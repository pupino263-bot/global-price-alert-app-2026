# Global Price Alert — V13 verification pass (2026-10-12)

This package is a verification/documentation refresh based on V12; it does not claim a production release.

## Rechecked in this environment
- `cd backend && npm test`: PASS (source normalization, mocked eBay adapter, alert refresh/estimate semantics, API/auth/alerts/history/notifications/account deletion).
- `cd backend && npm run preflight`: PASS (13 required files and Android release safety guards).
- `node --check` for backend source/tests and release preflight: PASS.
- Pure Kotlin domain/taxonomy/architecture compilation with `kotlinc`: PASS.
- Android manifest and styles XML parse: PASS.
- V12 ZIP integrity: PASS.

## Still blocking publication
- Full Android Gradle/Compose build and device/emulator regression; this environment has no Gradle executable, Android SDK or Gradle wrapper.
- Deploy production HTTPS backend and PostgreSQL; execute migrations and production-mode tests.
- Configure and test an authorized live price source (eBay adapter is mocked until credentials/access are approved).
- Configure Firebase Cloud Messaging, Google Play Billing, ads and affiliate attribution.
- Complete Italian/English/French/Spanish/German UI localization and manual language selector.
- Publish privacy policy, terms, support contact and required store disclosures/assets.
- Configure release signing and produce/test a signed AAB in the Play Console workflow.

Do not treat the package as ready for public release until these blockers are resolved and verified.

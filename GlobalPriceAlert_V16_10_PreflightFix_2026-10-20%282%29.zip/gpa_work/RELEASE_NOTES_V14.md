# Global Price Alert — V14 verification package (2026-10-12)

V14 is based on the V13 package. It strengthens release workflow reliability and documents remaining release gates; it does not claim production readiness.

## Change
- Backend CI now runs the static release safety preflight as well as backend tests, independent of the Android build job.
- Added a pre-publication checklist distinguishing verified local checks from external/device-dependent blockers.
- Updated the root README to identify this package accurately.

## Rechecked
- Backend test suite: PASS.
- Release preflight: PASS.
- `node --check` for backend source, tests and scripts: PASS.
- Android manifest/style XML parsing: PASS.
- ZIP integrity: PASS.

## Still not verified
- Full Android Gradle build or physical-device regression.
- Deployed production HTTPS backend/PostgreSQL and live authorized store API.
- Complete five-language UI, Billing, ads, affiliate attribution and push notifications.
- Legal/store disclosures, release signing, signed AAB and Play Console testing.

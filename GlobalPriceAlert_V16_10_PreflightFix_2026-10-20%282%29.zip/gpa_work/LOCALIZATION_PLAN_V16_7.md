# Global Price Alert — localization scaffold V16.7

Date: 2026-10-20

## Approved locales (15)
Italian (`it`), English (`en`), Spanish (`es`), French (`fr`), German (`de`), Portuguese (`pt`), Simplified Chinese (`zh-rCN`), Japanese (`ja`), Arabic (`ar`), Hindi (`hi`), Korean (`ko`), Dutch (`nl`), Russian (`ru`), Polish (`pl`), Turkish (`tr`).

## Added in this package
- Android `strings.xml` resource sets created for all 15 locales, including a small starter set of common app labels and descriptions.
- Locale resource folders use Android resource qualifiers; default Italian resources are in `values/`.
- `supportsRtl=true` was already present in the Android manifest.

## Important status
This is a **localization scaffold**, not a completed 15-language app. The current Jetpack Compose UI still contains hard-coded Italian text, so the new resources are not yet wired into all screens. Locale switching/settings, full UI translation, RTL layout verification, font/layout checks, search-language behavior, Play Store listing translations, and device testing remain outstanding. Translations here are starter strings and require native/professional review before release.

## Next implementation gate
Replace hard-coded UI literals with `stringResource(...)`, implement a persisted in-app locale selector (including supported locale configuration), audit all screens and notifications, then build and test each locale on Android. No APK/AAB was generated as part of this change.

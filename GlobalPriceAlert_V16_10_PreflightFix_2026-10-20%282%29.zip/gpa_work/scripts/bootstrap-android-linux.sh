#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TOOLS="$ROOT/.android-tools"
SDK="$TOOLS/sdk"
GRADLE_VERSION="8.11.1"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"

for tool in java curl unzip; do
  command -v "$tool" >/dev/null 2>&1 || { echo "ERRORE: manca $tool" >&2; exit 1; }
done
mkdir -p "$TOOLS" "$SDK/cmdline-tools"
if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  echo "Scarico Android Command-line Tools..."
  curl -fL --retry 3 "$CMDLINE_TOOLS_URL" -o "$tmp/cmdline-tools.zip"
  unzip -q "$tmp/cmdline-tools.zip" -d "$tmp/unpacked"
  mkdir -p "$SDK/cmdline-tools/latest"
  cp -a "$tmp/unpacked/cmdline-tools/." "$SDK/cmdline-tools/latest/"
fi
SDKMANAGER="$SDK/cmdline-tools/latest/bin/sdkmanager"
echo "Accetto le licenze SDK e installo API 36 / Build Tools 36.0.0..."
 yes | "$SDKMANAGER" --sdk_root="$SDK" --licenses >/dev/null || true
"$SDKMANAGER" --sdk_root="$SDK" "platform-tools" "platforms;android-36" "build-tools;36.0.0"
GRADLE_HOME="$TOOLS/gradle-$GRADLE_VERSION"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  echo "Scarico Gradle $GRADLE_VERSION..."
  curl -fL --retry 3 "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$tmp/gradle.zip"
  unzip -q "$tmp/gradle.zip" -d "$TOOLS"
fi
printf 'sdk.dir=%s\n' "$SDK" > "$ROOT/local.properties"
echo "Setup completato. SDK: $SDK"
echo "Compilazione: $GRADLE_HOME/bin/gradle -p '$ROOT' assembleDebug"

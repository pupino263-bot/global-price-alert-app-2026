$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Tools = Join-Path $Root '.android-tools'
$Sdk = Join-Path $Tools 'sdk'
$GradleVersion = '8.11.1'
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw 'Installa prima un JDK 17 o 21.' }
New-Item -ItemType Directory -Force -Path (Join-Path $Sdk 'cmdline-tools') | Out-Null
$SdkManager = Join-Path $Sdk 'cmdline-tools/latest/bin/sdkmanager.bat'
if (-not (Test-Path $SdkManager)) {
  $Zip = Join-Path $env:TEMP 'gpa-cmdtools.zip'
  $Extract = Join-Path $env:TEMP 'gpa-cmdtools'
  Invoke-WebRequest 'https://dl.google.com/android/repository/commandlinetools-win-13114758_latest.zip' -OutFile $Zip
  Remove-Item $Extract -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive $Zip $Extract -Force
  $Latest = Join-Path $Sdk 'cmdline-tools/latest'
  New-Item -ItemType Directory -Force -Path $Latest | Out-Null
  Copy-Item (Join-Path $Extract 'cmdline-tools/*') $Latest -Recurse -Force
}
$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk
& $SdkManager --sdk_root=$Sdk 'platform-tools' 'platforms;android-36' 'build-tools;36.0.0'
if ($LASTEXITCODE -ne 0) { throw 'Installazione SDK fallita.' }
$GradleHome = Join-Path $Tools "gradle-$GradleVersion"
if (-not (Test-Path (Join-Path $GradleHome 'bin/gradle.bat'))) {
  $GradleZip = Join-Path $env:TEMP 'gpa-gradle.zip'
  Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $GradleZip
  Expand-Archive $GradleZip $Tools -Force
}
Set-Content -Path (Join-Path $Root 'local.properties') -Value "sdk.dir=$($Sdk.Replace('\','/'))"
Write-Host "Setup completato. Compila con: $GradleHome\bin\gradle.bat -p `"$Root`" assembleDebug"

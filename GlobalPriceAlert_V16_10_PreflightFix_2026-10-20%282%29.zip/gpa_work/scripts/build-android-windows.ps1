$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Gradle = Join-Path $Root '.android-tools/gradle-8.11.1/bin/gradle.bat'
$Sdk = Join-Path $Root '.android-tools/sdk'
$LocalProperties = Join-Path $Root 'local.properties'

if (-not (Test-Path $Gradle)) {
  throw 'Gradle non trovato. Esegui prima: powershell -ExecutionPolicy Bypass -File .\\scripts\\bootstrap-android-windows.ps1'
}
if (-not (Test-Path $LocalProperties)) {
  throw 'Android SDK non configurato. Esegui prima lo script bootstrap-android-windows.ps1.'
}
$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk
Set-Location $Root
& $Gradle --no-daemon clean assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Build Android fallita con codice $LASTEXITCODE" }
$Apk = Join-Path $Root 'app/build/outputs/apk/debug/app-debug.apk'
if (-not (Test-Path $Apk)) { throw 'Gradle ha terminato ma l’APK atteso non esiste.' }
$Hash = (Get-FileHash $Apk -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "BUILD PASS: $Apk"
Write-Host "SHA256: $Hash"

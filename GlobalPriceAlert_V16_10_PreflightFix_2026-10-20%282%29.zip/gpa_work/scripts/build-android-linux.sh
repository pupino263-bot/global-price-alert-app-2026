#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GRADLE="$ROOT/.android-tools/gradle-8.11.1/bin/gradle"
[[ -x "$GRADLE" ]] || { echo "Esegui prima ./scripts/bootstrap-android-linux.sh" >&2; exit 1; }
[[ -f "$ROOT/local.properties" ]] || { echo "SDK non configurato: esegui prima il bootstrap." >&2; exit 1; }
cd "$ROOT"
"$GRADLE" --no-daemon assembleDebug
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"

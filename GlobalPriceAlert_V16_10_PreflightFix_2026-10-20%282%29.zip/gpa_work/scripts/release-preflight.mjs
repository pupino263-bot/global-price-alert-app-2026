import { readFile, access } from 'node:fs/promises';
import { constants } from 'node:fs';
import assert from 'node:assert/strict';

const read = (p) => readFile(new URL(`../${p}`, import.meta.url), 'utf8');
const requiredFiles = [
  'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
  'app/src/main/AndroidManifest.xml', 'app/src/main/java/com/globalpricealert/app/MainActivity.kt',
  'app/src/main/java/com/globalpricealert/app/BackendClient.kt',
  'app/src/main/java/com/globalpricealert/app/SessionVault.kt',
  'backend/src/server.mjs', 'backend/src/monitoring.mjs', 'backend/src/compatibility.mjs', 'backend/src/postgres-store.mjs',
  'backend/sql/001_core.sql', 'backend/sql/004_alert_monitoring.sql',
  '.github/workflows/backend-tests.yml',
  'scripts/bootstrap-android-linux.sh', 'scripts/build-android-linux.sh',
  'scripts/bootstrap-android-windows.ps1', 'scripts/build-android-windows.ps1'
];
for (const path of requiredFiles) {
  await access(new URL(`../${path}`, import.meta.url), constants.R_OK);
}

const gradle = await read('app/build.gradle.kts');
const rootGradle = await read('build.gradle.kts');
const manifest = await read('app/src/main/AndroidManifest.xml');
const taxonomy = await read('app/src/main/java/com/globalpricealert/app/CategoryTaxonomy.kt');
const main = await read('app/src/main/java/com/globalpricealert/app/MainActivity.kt');
const workflow = await read('.github/workflows/backend-tests.yml');
const sourceLogic = await read('backend/src/sources.mjs');
const sourceTests = await read('backend/test/sources.test.mjs');
const compatibilityTests = await read('backend/test/compatibility.test.mjs');

assert.match(gradle, /compileSdk\s*=\s*36/, 'compileSdk must remain at 36');
assert.match(gradle, /targetSdk\s*=\s*36/, 'targetSdk must remain at 36');
assert.match(rootGradle, /id\(\"org\.jetbrains\.kotlin\.plugin\.compose\"\)\s+version\s+\"2\.1\.10\"\s+apply false/, 'Kotlin Compose plugin version must match Kotlin 2.1.10');
assert.match(gradle, /id\(\"org\.jetbrains\.kotlin\.plugin\.compose\"\)/, 'app must apply Kotlin Compose plugin');
assert.match(gradle, /compose\s*=\s*true/, 'Compose build feature must be explicitly enabled');
assert.match(gradle, /releaseBackendUrl\.startsWith\("https:\/\/"\)/, 'release must require HTTPS backend');
assert.match(manifest, /allowBackup="false"/, 'Android backup must stay disabled for session-bearing app');
assert.match(taxonomy, /Componenti e ricambi/);
assert.match(taxonomy, /Consumabili/);
assert.match(taxonomy, /Prodotti compatibili/);
assert.match(taxonomy, /Varianti professionali e specialistiche/);
assert.match(sourceLogic, /function isValidGtin\(/, 'product matching must validate GTIN check digits');
assert.match(sourceLogic, /Permit human-readable spaces\/hyphens, but never silently strip arbitrary letters/, 'GTIN parsing must reject contaminated non-numeric identifiers');
assert.match(sourceLogic, /o\.shippingKnown !== true \|\| o\.taxesKnown !== true \|\| o\.mandatoryFeesKnown !== true/, 'unknown cost components must fail closed as estimates');
assert.match(sourceLogic, /invalid_discount_exceeds_gross_total/, 'discount must not reduce an offer below a fabricated zero total');
assert.match(sourceTests, /valid-gtin14/, 'GTIN matching regression tests must cover GTIN-14');
assert.match(sourceTests, /invalidGtin/, 'GTIN checksum fallback regression test must remain present');
assert.match(sourceTests, /different storage\/color variants must not be merged/, 'material variants must remain separate');
assert.match(compatibilityTests, /unknown/, 'Smart Compatibility must preserve an unknown state when evidence is insufficient');
assert.match(await read('backend/src/server.mjs'), /\/v1\/compatibility\/check/, 'compatibility assessment endpoint must be registered');
const categoryNames = [...taxonomy.matchAll(/CategoryNode\("([^\"]+)"/g)].map((match) => match[1]);
assert.ok(categoryNames.length >= 34, `expected broad category coverage; found ${categoryNames.length}`);
assert.equal(new Set(categoryNames).size, categoryNames.length, 'top-level category names must be unique');
for (const category of [
  'Gioielli e bigiotteria', 'Artigianato, filati e merceria', 'Tatuaggi e body art',
  'Integratori e nutrizione sportiva', 'Riscaldamento, climatizzazione ed energia',
  'Domotica, reti e automazione', 'Macchinari e impianti industriali',
  'Idraulica e trattamento acqua', 'Software e servizi digitali'
]) assert.ok(categoryNames.includes(category), `missing required category: ${category}`);
assert.match(main, /R\.string\.demo_mode|non sono prezzi live|non prezzi live/i, 'demo results must be clearly identified, including through localized resources');
assert.match(main, /R\.string\.premium_message|L'acquisto non è ancora collegato/, 'Premium must not be represented as purchasable until billing exists, including through localized resources');
assert.match(main, /enabled = !offer\.costIsEstimate && offer\.effectiveCost\.isFinite\(\) && offer\.effectiveCost > 0\.0/, 'price alerts must be disabled for estimated or invalid totals');
assert.match(main, /R\.string\.[a-zA-Z0-9_]*(?:cost|estimate)[a-zA-Z0-9_]*|costo completo verificabile/i, 'estimated-cost alert limitation must be explained in the UI, including through localized resources');
assert.match(workflow, /workflow_dispatch:/, 'Android build workflow must be manually runnable from GitHub Actions');
assert.match(workflow, /assembleDebug/, 'CI must compile the Android debug app');
assert.match(workflow, /upload-artifact@v4/, 'CI must upload the debug APK artifact');
assert.match(workflow, /gradle-version:\s*'8\.11\.1'/, 'CI Gradle version must match the documented toolchain');
assert.match(workflow, /platforms;android-36/, 'CI must install Android SDK API 36');
assert.match(await read('scripts/bootstrap-android-linux.sh'), /GRADLE_VERSION="8\.11\.1"/, 'Linux bootstrap Gradle version must match CI');
assert.match(await read('scripts/build-android-windows.ps1'), /assembleDebug/, 'Windows build helper must compile the Android debug app');
console.log(`release preflight PASS: ${requiredFiles.length} required files, Android release safety guards, GTIN validation, and fail-closed cost checks checked`);
console.log('NOTE: this is a static preflight; it does not replace Gradle compilation, device testing, live API/database checks, or Play release validation.');

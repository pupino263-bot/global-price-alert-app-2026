# Pre-publication guard update — 16 October 2026

This source bundle is based on `GlobalPriceAlert_V16_1_reviewed.zip`. It adds regression checks to `scripts/release-preflight.mjs`; it does not change application runtime behavior.

## Change made
The static release preflight now also requires:
1. `org.jetbrains.kotlin.plugin.compose` version `2.1.10` in the root Gradle plugin declarations;
2. the Compose plugin applied in `app/build.gradle.kts`;
3. the Compose build feature explicitly enabled.

These checks protect the correction already present in V16.1 from accidental removal. They do not prove that Gradle/Compose compiles.

## Verification performed on this bundle
- `node scripts/release-preflight.mjs`: PASS.
- `node --check scripts/release-preflight.mjs`: PASS.
- Backend `npm test`: PASS.
- `node --check` on all backend source/test `.mjs` files: PASS.
- `bash -n` on both Linux Android bootstrap/build scripts: PASS.
- Android XML parse: PASS (3 files).
- Kotlin domain/taxonomy/architecture compile with `kotlinc`: PASS.
- Negative regression test: removed the Compose plugin and `compose = true` in a temporary copy; preflight failed as intended, so the new guard catches the regression.
- ZIP integrity: checked after packaging.

## Still not verified
No Android Gradle build was run. This environment has no Gradle executable or Android SDK installed, and no accessible linked GitHub repository was returned. No APK/AAB or device test is claimed. Live store credentials, production backend, Google Play Billing, ads/affiliate attribution, release signing and Play Console setup remain open.

# Global Price Alert — localization and test report V16.9

Scope remains limited to localization and verification; search, offer, account, alert, compatibility and monetization logic were not intentionally changed.

## Translation update
- Expanded complete long-form translations in English, Spanish, French and German, Portuguese resource strings, including account, alerts, demo-mode and Premium disclosures.
- Italian remains the default source language. The other 10 locales (Simplified Chinese, Japanese, Arabic, Hindi, Korean, Dutch, Russian, Polish, Turkish and any strings not explicitly reviewed in these resources) still require full professional/native review; do not treat all 15 locales as release-ready.
- Android language resources contain 67 matching keys in each of the 15 locale resource files.

## Tests performed
- All 15 `strings.xml` files parse as valid XML: PASS.
- All 15 locales have the same 67 resource keys: PASS.
- Android string format placeholders match the Italian base resources: PASS.
- Backend `npm test`: PASS for source normalization/failure isolation, Smart Compatibility, mocked eBay adapter, alert monitoring, and API integration/security-related cases.
- Release preflight: FAIL. Existing preflight script expects the demo disclaimer to match a hard-coded source string in `MainActivity.kt`; the disclaimer is now provided through `R.string.demo_mode`. This is a localization-aware test expectation that must be updated/confirmed, not evidence of a backend test failure. No unrelated code was changed to bypass it.
- Android Gradle compilation/device test: NOT RUN. This environment has no Gradle executable or Gradle wrapper in the archive, and Android SDK build availability is not established. No APK/AAB was produced.

## Release status
Localization wiring is partially validated, but the full Android build and device tests are still a release blocker. Translations in the remaining locales need completion and native review before claiming full 15-language support.

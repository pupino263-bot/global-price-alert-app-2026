import assert from 'node:assert/strict';
import {EbayBrowseSource, createConfiguredSources, normalizeOffer, dedupeOffers} from '../src/sources.mjs';

const calls=[];
const mockFetch=async (url, options={})=>{
  calls.push({url:String(url),options});
  if(String(url).includes('/identity/v1/oauth2/token')) return {ok:true,status:200,json:async()=>({access_token:'test-access-token',expires_in:7200})};
  assert.ok(String(url).includes('/buy/browse/v1/item_summary/search?'));
  assert.equal(options.headers['X-EBAY-C-MARKETPLACE-ID'],'EBAY_IT');
  assert.equal(options.headers.Authorization,'Bearer test-access-token');
  return {ok:true,status:200,json:async()=>({itemSummaries:[
    {itemId:'v1',title:'Ricambio A',price:{value:'100.00',currency:'EUR'},itemWebUrl:'https://www.ebay.it/itm/v1',brand:'Maker',mpn:'A-1',gtin:'12345670',shippingOptions:[{shippingCost:{value:'5.00',currency:'EUR'}}]},
    {itemId:'v2',title:'Ricambio B',price:{value:'90.00',currency:'EUR'},itemWebUrl:'https://www.ebay.it/itm/v2',shippingOptions:[]}
  ]})};
};
const source=new EbayBrowseSource({clientId:'test-client',clientSecret:'test-secret',fetchImpl:mockFetch});
assert.equal(source.isConfigured,true);
const first=await source.search({query:'ricambio',countryCode:'IT',maxResults:10});
assert.equal(first.length,2);
assert.equal(first[0].sourceId,'ebay');
assert.equal(first[0].shipping,5);
assert.equal(first[0].shippingKnown,true);
assert.equal(first[0].taxesKnown,false);
assert.equal(first[0].costIsEstimate,true,'checkout taxes and mandatory fees are not returned by this summary mapping');
assert.equal(normalizeOffer({id:'missing-flags',sourceId:'s',title:'Unverified total',price:10}).costIsEstimate,true,'unknown cost components must not be treated as zero');
assert.equal(first[1].shippingKnown,false,'unknown shipping must not be silently treated as confirmed free shipping');
await source.search({query:'second call',countryCode:'IT',maxResults:10});
assert.equal(calls.filter(c=>c.url.includes('/identity/v1/oauth2/token')).length,1,'OAuth token must be cached until near expiry');
assert.equal(calls.filter(c=>c.url.includes('/item_summary/search')).length,2);
assert.equal(createConfiguredSources({}).length,0);
assert.equal(createConfiguredSources({EBAY_CLIENT_ID:'id',EBAY_CLIENT_SECRET:'secret'}).length,1);
assert.throws(()=>normalizeOffer({id:'bad',sourceId:'s',title:'Bad',price:1,shipping:-1}),/invalid_shipping/);
const sorted=dedupeOffers([
  {id:'estimate',sourceId:'s1',title:'Estimate',price:20,shipping:0,costIsEstimate:true},
  {id:'known',sourceId:'s2',title:'Known',price:40,shipping:0,costIsEstimate:false,shippingKnown:true,taxesKnown:true,mandatoryFeesKnown:true}
]);
assert.equal(sorted[0].id,'known','offers with a complete cost breakdown rank before estimates');
const withTax=normalizeOffer({id:'tax',sourceId:'s',title:'Taxed',price:100,shipping:5,taxes:22,mandatoryFees:2,discount:10});
assert.equal(withTax.effectiveCost,119);
console.log('eBay Browse adapter mocked OAuth, marketplace mapping, token cache and estimate semantics tests: PASS');

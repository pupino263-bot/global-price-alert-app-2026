import assert from 'node:assert/strict';
import {refreshAlertPrices} from '../src/monitoring.mjs';
const alerts=[
  {id:'a1',productKey:'gtin:12345678',query:'part x',category:'Auto e moto',countryCode:'IT',currency:'EUR'},
  {id:'a2',productKey:'gtin:87654321',query:'part x',category:'Auto e moto',countryCode:'IT',currency:'EUR'},
  {id:'a3',productKey:'gtin:99999999',query:'part y',category:'Auto e moto',countryCode:'IT',currency:'EUR'}
];
const calls=[], snapshots=[], checked=[];
const result=await refreshAlertPrices({
  listAlerts:async()=>alerts,
  markAlertChecked:async id=>checked.push(id),
  search:async req=>{calls.push(req); return {sources:[{sourceId:'mock',status:'ok'}],offers:[
    {id:'offer1',sourceId:'mock',title:'Part X',normalizedProductKey:'gtin:12345678',currency:'EUR',price:10,shipping:0,mandatoryFees:0,taxes:0,discount:0,costIsEstimate:false},
    {id:'offer2',sourceId:'mock',title:'Part X second offer',normalizedProductKey:'gtin:87654321',currency:'EUR',price:12,shipping:0,mandatoryFees:0,taxes:0,discount:0,costIsEstimate:true},
    {id:'offer3',sourceId:'mock',title:'Part Y',normalizedProductKey:'gtin:99999999',currency:'EUR',price:20,shipping:0,mandatoryFees:0,taxes:0,discount:0,costIsEstimate:false}
  ]};},
  addSnapshot:async x=>snapshots.push(x),
  limit:20,
  concurrency:2
});
assert.equal(calls.length,2,'alerts sharing the same search context must share one marketplace search');
assert.equal(result.alertsConsidered,3);
assert.equal(result.searchGroups,2);
assert.equal(result.snapshotsAdded,3);
assert.equal(snapshots.filter(s=>s.costIsEstimate).length,1,'estimate status must be preserved in history');
assert.equal(checked.length,3);
console.log('alert refresh grouping, snapshots and estimate propagation tests: PASS');

import assert from 'node:assert/strict';
import {normalizeOffer,dedupeOffers,groupOffersByProduct,SourceRegistry} from '../src/sources.mjs';
const a=normalizeOffer({id:'a',sourceId:'one',gtin:'12345670',brand:'Brand',model:'X',title:'Product',price:100,shipping:5,mandatoryFees:2,discount:10,shippingKnown:true,taxesKnown:true,mandatoryFeesKnown:true});
assert.equal(a.effectiveCost,97);
assert.equal(a.normalizedProductKey,'gtin:12345670');
const offers=dedupeOffers([
  a,
  {id:'a',sourceId:'one',gtin:'12345670',brand:'Brand',model:'X',title:'Product',price:100,shipping:5,mandatoryFees:2,discount:10,shippingKnown:true,taxesKnown:true,mandatoryFeesKnown:true},
  {id:'b',sourceId:'two',gtin:'12345670',brand:'Brand',model:'X',title:'Product',price:90,shipping:15}
]);
assert.equal(offers.length,2,'same product in different stores must remain visible');
assert.equal(offers[0].effectiveCost,97);
assert.equal(groupOffersByProduct(offers).length,1);
assert.equal(groupOffersByProduct(offers)[0].offers.length,2);
const variantBlack = normalizeOffer({id:'black-128',sourceId:'store-a',brand:'DemoBrand',model:'Phone X',title:'DemoBrand Phone X 128 GB Black',price:100});
const variantWhite = normalizeOffer({id:'white-256',sourceId:'store-b',brand:'DemoBrand',model:'Phone X',title:'DemoBrand Phone X 256GB White',price:110});
const variantBlackTranslated = normalizeOffer({id:'black-128-fr',sourceId:'store-c',brand:'DemoBrand',model:'Phone X',title:'DemoBrand Phone X 128GB Noir',price:99});
assert.notEqual(variantBlack.normalizedProductKey, variantWhite.normalizedProductKey, 'different storage/color variants must not be merged');
assert.equal(variantBlack.normalizedProductKey, variantBlackTranslated.normalizedProductKey, 'common color aliases and capacity spacing should normalize consistently');
assert.equal(variantBlack.productFamilyKey, variantWhite.productFamilyKey, 'variants retain a shared model family key');
assert.equal(groupOffersByProduct([variantBlack, variantWhite]).length, 2, 'price ranking must not mix materially different variants');
const crossCurrency=groupOffersByProduct(dedupeOffers([
  {id:'eur',sourceId:'eur-store',gtin:'87654325',title:'Same item',price:100,currency:'EUR'},
  {id:'usd',sourceId:'usd-store',gtin:'87654325',title:'Same item',price:1,currency:'USD'}
]))[0];
assert.equal(crossCurrency.bestEffectiveCost,null,'do not compare raw amounts across currencies');
assert.equal(crossCurrency.bestEffectiveCostByCurrency.EUR.bestEffectiveCost,100);
assert.equal(crossCurrency.bestEffectiveCostByCurrency.USD.bestEffectiveCost,1);
assert.throws(()=>normalizeOffer({id:'x',sourceId:'s',title:'Bad',price:-1}),/invalid_price/);
assert.throws(()=>normalizeOffer({id:'x',sourceId:'s',title:'Bad',price:10,currency:'EURO'}),/invalid_currency/);
assert.throws(()=>normalizeOffer({id:'x',sourceId:'s',title:'Bad',price:10,discount:11}),/invalid_discount_exceeds_gross_total/);
const invalidGtin=normalizeOffer({id:'bad-gtin',sourceId:'s',gtin:'12345678',brand:'Brand',model:'Model Z',title:'Model Z item',price:10});
assert.equal(invalidGtin.normalizedProductKey,'brand-model:brand|model z','invalid GTIN check digit must not drive product matching');
const contaminatedGtin=normalizeOffer({id:'contaminated-gtin',sourceId:'s',gtin:'EAN 12345670',brand:'Brand',model:'Model Q',title:'Model Q item',price:10});
assert.equal(contaminatedGtin.normalizedProductKey,'brand-model:brand|model q','letters in a GTIN field must not be stripped into a false valid barcode');
const validGtin13=normalizeOffer({id:'valid-ean',sourceId:'s',gtin:'4006381333931',title:'EAN product',price:10});
assert.equal(validGtin13.normalizedProductKey,'gtin:4006381333931','valid GTIN-13 should be used for exact matching');
assert.equal(normalizeOffer({id:'valid-gtin8',sourceId:'s',gtin:'12345670',title:'EAN-8 item',price:10}).normalizedProductKey,'gtin:12345670');
assert.equal(normalizeOffer({id:'valid-gtin12',sourceId:'s',gtin:'036000291452',title:'UPC item',price:10}).normalizedProductKey,'gtin:036000291452');
assert.equal(normalizeOffer({id:'valid-gtin14',sourceId:'s',gtin:'10012345000017',title:'GTIN-14 item',price:10}).normalizedProductKey,'gtin:10012345000017');
const incompleteCost=normalizeOffer({id:'incomplete',sourceId:'s',title:'Unknown shipping item',price:10});
assert.equal(incompleteCost.costIsEstimate,true,'missing cost-completeness declarations must fail closed');
const invalidGtinLength=normalizeOffer({id:'bad-length',sourceId:'s',gtin:'123456789',title:'Nine digit item',price:10});
assert.equal(invalidGtinLength.normalizedProductKey,'title:|nine digit item','non-standard GTIN length must fall back to title matching');
const registry=new SourceRegistry([
  {id:'good',search:async()=>[{id:'1',sourceId:'good',title:'Good',price:10}]},
  {id:'bad',search:async()=>{throw new Error('provider down')}}
],{timeoutMs:100});
const result=await registry.searchDetailed({maxResults:10});
assert.equal(result.offers.length,1);
assert.equal(result.sources.find(x=>x.sourceId==='bad').status,'error');
const timeoutRegistry=new SourceRegistry([{id:'slow',search:()=>new Promise(r=>setTimeout(()=>r([]),100))}],{timeoutMs:10});
const timeoutResult=await timeoutRegistry.searchDetailed({maxResults:10});
assert.equal(timeoutResult.sources[0].status,'timeout');
console.log('source normalization, multi-store preservation and failure isolation tests: PASS');

import assert from 'node:assert/strict';
import {assessCompatibility} from '../src/compatibility.mjs';

const exact = assessCompatibility({partNumber:'ABC-123'}, {partNumber:'abc 123'});
assert.equal(exact.status, 'confirmed');
assert.equal(exact.confidence, 1);

const voltageMismatch = assessCompatibility(
  {voltage:'12 V', connector:'Type A'},
  {voltage:'24V', connector:'Type A'}
);
assert.equal(voltageMismatch.status, 'incompatible');
assert.ok(voltageMismatch.evidence.some(x => x.includes('voltage')));

const fitment = assessCompatibility(
  {vehicleModel:'Honda SH 125'},
  {compatibleModels:['Honda SH 125', 'Honda SH 150']}
);
assert.equal(fitment.status, 'confirmed');

const completeFitmentMiss = assessCompatibility(
  {vehicleModel:'Honda SH 125'},
  {compatibleModels:['Honda SH 150'], fitmentComplete:true}
);
assert.equal(completeFitmentMiss.status, 'incompatible');

const uncertainPartNumber = assessCompatibility(
  {partNumber:'ABC-123'},
  {partNumber:'XYZ-999'}
);
assert.equal(uncertainPartNumber.status, 'unknown', 'different part numbers alone must not assert incompatibility');

const noEvidence = assessCompatibility({}, {});
assert.equal(noEvidence.status, 'unknown');
assert.equal(noEvidence.confidence, 0);
console.log('conservative Smart Compatibility assessment tests: PASS');

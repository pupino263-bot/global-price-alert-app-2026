const base=(process.env.GPA_BASE_URL||'http://127.0.0.1:8787').replace(/\/$/,'');
const key=process.env.GPA_INTERNAL_KEY||'';
if(!key) { console.error('GPA_INTERNAL_KEY is required'); process.exit(1); }
const intervalMs=Math.max(15_000,Number(process.env.GPA_WORKER_INTERVAL_MS)||60_000);
const once=process.argv.includes('--once');
let stopping=false;
for(const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>{stopping=true;});
async function callInternal(route, timeoutMs=75_000){
  const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(),timeoutMs);
  try {
    const r=await fetch(`${base}${route}`,{method:'POST',headers:{'x-internal-key':key},signal:controller.signal});
    if(!r.ok) throw new Error(`worker_http_${r.status}`);
    return await r.json();
  } finally { clearTimeout(timeout); }
}
async function tick(){
  try {
    const refresh=await callInternal('/v1/internal/refresh-alerts');
    console.log(new Date().toISOString(),'price refresh',JSON.stringify(refresh));
  } catch(e) { console.error(new Date().toISOString(),'price refresh failed:',e.message); }
  try {
    const result=await callInternal('/v1/internal/evaluate-alerts',15_000);
    console.log(new Date().toISOString(),'alert evaluation',JSON.stringify(result));
  } catch(e) { console.error(new Date().toISOString(),'alert evaluation failed:',e.message); }
}
do {
  await tick();
  if(once || stopping) break;
  await new Promise(resolve=>setTimeout(resolve,intervalMs));
} while(!stopping);

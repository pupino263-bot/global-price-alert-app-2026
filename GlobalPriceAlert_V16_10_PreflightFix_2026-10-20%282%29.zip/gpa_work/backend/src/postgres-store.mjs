import crypto from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;
const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error('DATABASE_URL_required');
const pool = new Pool({
  connectionString,
  max: Math.max(2, Math.min(20, Number(process.env.GPA_DB_POOL_MAX) || 10)),
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000,
  ssl: process.env.GPA_DB_SSL === 'disable' ? false : (process.env.GPA_DB_SSL === 'require' ? { rejectUnauthorized: process.env.GPA_DB_SSL_REJECT_UNAUTHORIZED !== 'false' } : undefined),
});
pool.on('error', err => console.error('postgres_idle_client_error', err.message));

const isoNow = () => new Date().toISOString();
const clean = (v, max=300) => String(v ?? '').trim().slice(0,max);
const hashToken = token => crypto.createHash('sha256').update(token).digest('hex');
const hashPassword = (password, salt) => crypto.scryptSync(password, salt, 64).toString('hex');
function currencyCode(value='EUR') { const c=String(value ?? 'EUR').trim().toUpperCase(); if(!/^[A-Z]{3}$/.test(c)) throw new Error('invalid_currency'); return c; }
function amount(value, fallback=0) { const n=Number(value ?? fallback); if(!Number.isFinite(n)||n<0) throw new Error('invalid_snapshot_amount'); return n; }
const round2 = n => Math.max(0, Math.round((n + Number.EPSILON) * 100) / 100);
function mapAlert(r) { return {id:r.id,userId:r.user_id,productKey:r.product_key,targetPrice:Number(r.target_price),currency:r.currency.trim(),query:r.query||'',category:r.category||'Tutte',countryCode:r.country_code||'IT',active:r.active,createdAt:new Date(r.created_at).toISOString(),triggeredAt:r.triggered_at?new Date(r.triggered_at).toISOString():null,cancelledAt:r.cancelled_at?new Date(r.cancelled_at).toISOString():null,lastCheckedAt:r.last_checked_at?new Date(r.last_checked_at).toISOString():null}; }
function mapSnapshot(r) { return {id:r.id,productKey:r.product_key,sourceId:r.source_id,offerId:r.offer_id,title:r.title,brand:r.brand,model:r.model,price:Number(r.price),shipping:Number(r.shipping),mandatoryFees:Number(r.mandatory_fees),taxes:Number(r.taxes||0),discount:Number(r.discount),effectiveCost:Number(r.effective_cost),costIsEstimate:r.cost_is_estimate===true,currency:r.currency.trim(),recordedAt:new Date(r.recorded_at).toISOString()}; }
function mapNotification(r) { const payload=typeof r.payload==='string'?JSON.parse(r.payload||'{}'):(r.payload||{}); return {id:r.id,userId:r.user_id,alertId:r.alert_id,type:r.type,...payload,createdAt:new Date(r.created_at).toISOString(),deliveredAt:r.delivered_at?new Date(r.delivered_at).toISOString():null,readAt:r.read_at?new Date(r.read_at).toISOString():null}; }

export async function healthCheck() {
  try { await pool.query('SELECT 1'); return {ok:true,storage:'postgresql'}; }
  catch { return {ok:false,storage:'postgresql'}; }
}

export async function createUser(email, password) {
  const normalized=String(email??'').trim().toLowerCase(), pass=String(password??'');
  if(normalized.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)||pass.length<8||pass.length>128) throw new Error('invalid_credentials');
  const id=crypto.randomUUID(), salt=crypto.randomBytes(16).toString('hex'), passwordHash=hashPassword(pass,salt);
  try { await pool.query('INSERT INTO users(id,email,password_hash,password_salt) VALUES($1,$2,$3,$4)',[id,normalized,passwordHash,salt]); }
  catch(e) { if(e.code==='23505') throw new Error('email_exists'); throw e; }
  return {id,email:normalized};
}

export async function login(email, password) {
  const normalized=String(email??'').trim().toLowerCase();
  if(normalized.length>254||typeof password!=='string'||password.length>128) throw new Error('invalid_credentials');
  const result=await pool.query('SELECT id,password_hash,password_salt FROM users WHERE email=$1',[normalized]);
  const account=result.rows[0];
  if(!account) { hashPassword(password, 'global-price-alert-dummy-salt'); throw new Error('invalid_credentials'); }
  const candidate=Buffer.from(hashPassword(password,account.password_salt),'hex'), expected=Buffer.from(account.password_hash,'hex');
  if(candidate.length!==expected.length||!crypto.timingSafeEqual(candidate,expected)) throw new Error('invalid_credentials');
  const token=crypto.randomBytes(32).toString('base64url'), expiresIn=30*24*3600;
  await pool.query('INSERT INTO app_sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+($3 * interval \'1 second\'))',[hashToken(token),account.id,expiresIn]);
  return {token,userId:account.id,expiresIn};
}
export async function authenticate(token) {
  if(!token||typeof token!=='string'||token.length>256) return null;
  const r=await pool.query('SELECT user_id FROM app_sessions WHERE token_hash=$1 AND expires_at>now()',[hashToken(token)]);
  return r.rows[0]?.user_id||null;
}
export async function revokeSession(token) {
  if(!token||typeof token!=='string'||token.length>256) return false;
  const r=await pool.query('DELETE FROM app_sessions WHERE token_hash=$1',[hashToken(token)]); return r.rowCount>0;
}
export async function deleteUser(userId) { const r=await pool.query('DELETE FROM users WHERE id=$1',[userId]); return r.rowCount>0; }

export async function createAlert(alert) {
  const productKey=clean(alert.productKey,300), targetPrice=Number(alert.targetPrice), currency=currencyCode(alert.currency||'EUR');
  if(!productKey||!Number.isFinite(targetPrice)||targetPrice<=0) throw new Error('invalid_alert');
  const query=clean(alert.query,200), category=clean(alert.category||'Tutte',120)||'Tutte', countryCode=String(alert.countryCode||'IT').trim().toUpperCase();
  if(!/^[A-Z]{2}$/.test(countryCode)) throw new Error('invalid_country_code');
  const id=crypto.randomUUID();
  const r=await pool.query('INSERT INTO alerts(id,user_id,product_key,target_price,currency,query,category,country_code) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',[id,alert.userId,productKey,targetPrice,currency,query,category,countryCode]);
  return mapAlert(r.rows[0]);
}
export async function listAlerts(userId) {
  const r=await pool.query('SELECT * FROM alerts WHERE user_id=$1 AND active=true ORDER BY created_at DESC',[userId]); return r.rows.map(mapAlert);
}
export async function listMonitorableAlerts({limit=20, minIntervalMs=15*60*1000}={}) {
  const count=Math.min(100,Math.max(1,Number(limit)||20));
  const r=await pool.query(`SELECT * FROM alerts WHERE active=true AND query<>'' AND (last_checked_at IS NULL OR last_checked_at <= now()-($2 * interval '1 millisecond')) ORDER BY last_checked_at ASC NULLS FIRST LIMIT $1`,[count,minIntervalMs]);
  return r.rows.map(mapAlert);
}
export async function markAlertChecked(alertId) {
  const r=await pool.query('UPDATE alerts SET last_checked_at=now() WHERE id=$1 AND active=true',[alertId]); return r.rowCount>0;
}
export async function deactivateAlert(userId, alertId) {
  const r=await pool.query('UPDATE alerts SET active=false,cancelled_at=now() WHERE id=$1 AND user_id=$2 AND active=true',[alertId,userId]); return r.rowCount>0;
}
export async function addSnapshot(snapshot) {
  const productKey=clean(snapshot.productKey,300), sourceId=clean(snapshot.sourceId,80), offerId=clean(snapshot.offerId,160), currency=currencyCode(snapshot.currency||'EUR');
  if(!productKey||!sourceId||!offerId) throw new Error('invalid_snapshot_identity');
  const price=amount(snapshot.price ?? snapshot.effectiveCost), shipping=amount(snapshot.shipping), mandatoryFees=amount(snapshot.mandatoryFees), taxes=amount(snapshot.taxes), discount=amount(snapshot.discount);
  const effectiveCost=round2(price+shipping+mandatoryFees+taxes-discount), id=crypto.randomUUID();
  const costIsEstimate=snapshot.costIsEstimate===true;
  const r=await pool.query(`INSERT INTO price_snapshots(id,product_key,source_id,offer_id,title,brand,model,price,shipping,mandatory_fees,taxes,discount,effective_cost,currency,cost_is_estimate)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,[id,productKey,sourceId,offerId,clean(snapshot.title,240),clean(snapshot.brand,100),clean(snapshot.model,100),price,shipping,mandatoryFees,taxes,discount,effectiveCost,currency,costIsEstimate]);
  return mapSnapshot(r.rows[0]);
}
export async function getPriceHistory(productKey, limit=90) {
  const key=clean(productKey,300), count=Math.min(365,Math.max(1,Number(limit)||90));
  const r=await pool.query('SELECT * FROM (SELECT * FROM price_snapshots WHERE product_key=$1 ORDER BY recorded_at DESC LIMIT $2) recent ORDER BY recorded_at ASC',[key,count]);
  return r.rows.map(mapSnapshot);
}
export async function addClick(click) {
  const sourceId=clean(click.sourceId,80), offerId=clean(click.offerId,160);
  if(!sourceId||!offerId) throw new Error('invalid_click');
  let destination; try { destination=new URL(String(click.destinationUrl)); } catch { throw new Error('invalid_destination_url'); }
  if(!['https:','http:'].includes(destination.protocol)||destination.username||destination.password) throw new Error('invalid_destination_url');
  const row={id:crypto.randomUUID(),userId:click.userId,sourceId,offerId,clickToken:crypto.randomUUID(),destinationUrl:destination.toString(),createdAt:isoNow()};
  await pool.query('INSERT INTO affiliate_clicks(id,user_id,source_id,offer_id,click_token,destination_url) VALUES($1,$2,$3,$4,$5,$6)',[row.id,row.userId,row.sourceId,row.offerId,row.clickToken,row.destinationUrl]);
  return row;
}
export async function getEntitlement(userId) {
  const r=await pool.query('SELECT * FROM entitlements WHERE user_id=$1',[userId]); const x=r.rows[0];
  if(!x) return {active:false,source:'none'};
  const status=x.status; return {active:status==='active'||status==='grace_period',source:x.provider,status,provider:x.provider,providerPurchaseId:x.provider_purchase_id,productId:x.product_id,expiresAt:x.expires_at?new Date(x.expires_at).toISOString():null,updatedAt:new Date(x.updated_at).toISOString()};
}
export async function setEntitlement(userId, entitlement) {
  const status=clean(entitlement.status||(entitlement.active?'active':'inactive'),24).toLowerCase();
  if(!['active','inactive','grace_period','cancelled','expired','pending'].includes(status)) throw new Error('invalid_entitlement_status');
  const provider=clean(entitlement.provider||'internal',80), purchaseId=entitlement.providerPurchaseId||null, productId=entitlement.productId||null, expiresAt=entitlement.expiresAt||null;
  const r=await pool.query(`INSERT INTO entitlements(user_id,provider,provider_purchase_id,product_id,status,expires_at,updated_at)
    VALUES($1,$2,$3,$4,$5,$6,now()) ON CONFLICT(user_id) DO UPDATE SET provider=EXCLUDED.provider,provider_purchase_id=EXCLUDED.provider_purchase_id,product_id=EXCLUDED.product_id,status=EXCLUDED.status,expires_at=EXCLUDED.expires_at,updated_at=now() RETURNING *`,[userId,provider,purchaseId,productId,status,expiresAt]);
  const x=r.rows[0]; return {active:x.status==='active'||x.status==='grace_period',source:x.provider,status:x.status,provider:x.provider,providerPurchaseId:x.provider_purchase_id,productId:x.product_id,expiresAt:x.expires_at?new Date(x.expires_at).toISOString():null,updatedAt:new Date(x.updated_at).toISOString()};
}

export async function evaluateAlerts({maxSnapshotAgeMs=24*3600*1000}={}) {
  const client=await pool.connect(); let triggered=0;
  try {
    await client.query('BEGIN');
    const alerts=await client.query('SELECT * FROM alerts WHERE active=true FOR UPDATE SKIP LOCKED');
    for(const alert of alerts.rows) {
      const snapshot=await client.query(`SELECT * FROM price_snapshots WHERE product_key=$1 AND currency=$2 AND cost_is_estimate=false AND recorded_at >= $3 AND recorded_at >= now()-($4 * interval '1 millisecond') ORDER BY recorded_at DESC LIMIT 1`,[alert.product_key,alert.currency.trim(),alert.created_at,maxSnapshotAgeMs]);
      if(!snapshot.rows.length) continue;
      const s=snapshot.rows[0];
      if(Number(s.effective_cost)<=Number(alert.target_price)) {
        const update=await client.query('UPDATE alerts SET active=false,triggered_at=now() WHERE id=$1 AND active=true',[alert.id]);
        if(!update.rowCount) continue;
        const payload={productKey:alert.product_key,effectiveCost:Number(s.effective_cost),currency:alert.currency.trim()};
        await client.query('INSERT INTO notifications(id,user_id,alert_id,type,payload) VALUES($1,$2,$3,$4,$5::jsonb)',[crypto.randomUUID(),alert.user_id,alert.id,'PRICE_DROP',JSON.stringify(payload)]);
        triggered++;
      }
    }
    await client.query('COMMIT'); return {triggered};
  } catch(e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}
export async function listNotifications(userId) {
  const r=await pool.query('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC',[userId]); return r.rows.map(mapNotification);
}
export async function markNotificationRead(userId, notificationId) {
  const r=await pool.query('UPDATE notifications SET read_at=COALESCE(read_at,now()) WHERE id=$1 AND user_id=$2',[notificationId,userId]); return r.rowCount>0;
}

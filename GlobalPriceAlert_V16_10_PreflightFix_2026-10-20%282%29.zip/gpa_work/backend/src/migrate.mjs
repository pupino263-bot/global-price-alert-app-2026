import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import pg from 'pg';

if(!process.env.DATABASE_URL) { console.error('DATABASE_URL is required to run migrations.'); process.exit(1); }
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:5000,ssl:process.env.GPA_DB_SSL==='disable'?false:(process.env.GPA_DB_SSL==='require'?{rejectUnauthorized:process.env.GPA_DB_SSL_REJECT_UNAUTHORIZED!=='false'}:undefined)});
const directory=path.resolve('sql');
const client=await pool.connect();
try {
  await client.query('CREATE TABLE IF NOT EXISTS schema_migrations (filename TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())');
  const files=(await fs.readdir(directory)).filter(f=>/^\d+_[a-z0-9_-]+\.sql$/i.test(f)).sort();
  for(const filename of files) {
    const sql=await fs.readFile(path.join(directory,filename),'utf8');
    const checksum=crypto.createHash('sha256').update(sql).digest('hex');
    const existing=await client.query('SELECT checksum FROM schema_migrations WHERE filename=$1',[filename]);
    if(existing.rows.length) {
      if(existing.rows[0].checksum!==checksum) throw new Error(`migration_checksum_mismatch:${filename}`);
      console.log(`migration already applied: ${filename}`); continue;
    }
    await client.query('BEGIN');
    try {
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations(filename,checksum) VALUES($1,$2)',[filename,checksum]);
      await client.query('COMMIT');
      console.log(`migration applied: ${filename}`);
    } catch(e) { await client.query('ROLLBACK'); throw e; }
  }
} finally { client.release(); await pool.end(); }

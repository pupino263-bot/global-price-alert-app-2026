import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dataDir = process.env.GPA_DATA_DIR || path.resolve('data');
const dataFile = path.join(dataDir, 'state.json');
const empty = {users: [], sessions: [], alerts: [], snapshots: [], clicks: [], entitlements: {}, notifications: []};
const isoNow = () => new Date().toISOString();
const clean = (v, max=300) => String(v ?? '').trim().slice(0,max);
function inferQuery(productKey) {
  const key=String(productKey||'');
  if(key.startsWith('gtin:')) return key.slice(5).slice(0,200);
  if(key.startsWith('brand-model:')) return key.slice(12).replace(/\|/g,' ').slice(0,200);
  if(key.startsWith('title:')) return key.slice(6).replace(/\|/g,' ').slice(0,200);
  return '';
}

function load() {
  fs.mkdirSync(dataDir, {recursive: true});
  if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify(empty, null, 2), {mode:0o600});
  const state = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  for (const key of Object.keys(empty)) if (state[key] === undefined) state[key] = structuredClone(empty[key]);
  return state;
}
function save(state) {
  fs.mkdirSync(dataDir, {recursive:true, mode:0o700});
  const temp = `${dataFile}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2), {mode:0o600});
  fs.renameSync(temp, dataFile);
}
function hashToken(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function hashPassword(password, salt) { return crypto.scryptSync(password, salt, 64).toString('hex'); }
function currencyCode(value='EUR') { const c=String(value ?? 'EUR').trim().toUpperCase(); if(!/^[A-Z]{3}$/.test(c)) throw new Error('invalid_currency'); return c; }

export function createUser(email, password) {
  const state = load(); const normalized = String(email ?? '').trim().toLowerCase(); const pass = String(password ?? '');
  if (normalized.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized) || pass.length < 8 || pass.length > 128) throw new Error('invalid_credentials');
  if (state.users.some(u => u.email === normalized)) throw new Error('email_exists');
  const salt = crypto.randomBytes(16).toString('hex');
  const user = {id:crypto.randomUUID(), email:normalized, salt, passwordHash:hashPassword(pass,salt), createdAt:isoNow()};
  state.users.push(user); save(state); return {id:user.id,email:user.email};
}
export function login(email, password) {
  const state = load(); const normalized = String(email ?? '').trim().toLowerCase();
  if (normalized.length > 254) throw new Error('invalid_credentials');
  const account = state.users.find(u => u.email === normalized);
  if (!account || typeof password !== 'string' || password.length > 128) throw new Error('invalid_credentials');
  const candidate = Buffer.from(hashPassword(password,account.salt),'hex');
  const expected = Buffer.from(account.passwordHash,'hex');
  if (candidate.length !== expected.length || !crypto.timingSafeEqual(candidate,expected)) throw new Error('invalid_credentials');
  const token = crypto.randomBytes(32).toString('base64url');
  const now = Date.now();
  state.sessions = state.sessions.filter(s => new Date(s.expiresAt).getTime() > now);
  state.sessions.push({tokenHash:hashToken(token),userId:account.id,createdAt:isoNow(),expiresAt:new Date(now+30*24*3600*1000).toISOString()});
  save(state); return {token,userId:account.id,expiresIn:30*24*3600};
}
export function authenticate(token) {
  if (!token || typeof token !== 'string' || token.length > 256) return null;
  const hash = hashToken(token); const state = load(); const now=Date.now();
  const session=state.sessions.find(s => s.tokenHash===hash && new Date(s.expiresAt).getTime()>now);
  return session?.userId || null;
}
export function revokeSession(token) {
  if (!token || typeof token !== 'string' || token.length > 256) return false;
  const state=load(); const hash=hashToken(token); const before=state.sessions.length;
  state.sessions=state.sessions.filter(s=>s.tokenHash!==hash);
  if(state.sessions.length===before) return false;
  save(state); return true;
}
export function deleteUser(userId) {
  const state=load(); const exists=state.users.some(u=>u.id===userId);
  if(!exists) return false;
  state.users=state.users.filter(u=>u.id!==userId);
  state.sessions=state.sessions.filter(s=>s.userId!==userId);
  state.alerts=state.alerts.filter(a=>a.userId!==userId);
  state.notifications=state.notifications.filter(n=>n.userId!==userId);
  state.clicks=state.clicks.map(c=>c.userId===userId?{...c,userId:null}:c);
  delete state.entitlements[userId];
  save(state); return true;
}
export function createAlert(alert) {
  const productKey=clean(alert.productKey,300); const targetPrice=Number(alert.targetPrice); const currency=currencyCode(alert.currency||'EUR');
  if (!productKey || !Number.isFinite(targetPrice) || targetPrice <= 0) throw new Error('invalid_alert');
  const query=clean(alert.query,200), category=clean(alert.category||'Tutte',120)||'Tutte';
  const countryCode=String(alert.countryCode||'IT').trim().toUpperCase();
  if(!/^[A-Z]{2}$/.test(countryCode)) throw new Error('invalid_country_code');
  const state=load(); const row={...alert,productKey,targetPrice,currency,query,category,countryCode,id:crypto.randomUUID(),createdAt:isoNow(),active:true,triggeredAt:null,lastCheckedAt:null};
  state.alerts.push(row); save(state); return row;
}
export function listAlerts(userId) { return load().alerts.filter(x => x.userId===userId && x.active).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)); }
export function listMonitorableAlerts({limit=20, minIntervalMs=15*60*1000}={}) {
  const now=Date.now(), count=Math.min(100,Math.max(1,Number(limit)||20)), state=load(); let changed=false;
  for(const alert of state.alerts) {
    if(!alert.query) { const inferred=inferQuery(alert.productKey); if(inferred) { alert.query=inferred; alert.category=alert.category||'Tutte'; alert.countryCode=alert.countryCode||'IT'; changed=true; } }
  }
  if(changed) save(state);
  return state.alerts.filter(a=>a.active && typeof a.query==='string' && a.query.trim() && (!a.lastCheckedAt || now-new Date(a.lastCheckedAt).getTime()>=minIntervalMs))
    .sort((a,b)=>new Date(a.lastCheckedAt||0)-new Date(b.lastCheckedAt||0)).slice(0,count);
}
export function markAlertChecked(alertId) {
  const state=load(), row=state.alerts.find(a=>a.id===alertId && a.active);
  if(!row) return false; row.lastCheckedAt=isoNow(); save(state); return true;
}
export function deactivateAlert(userId, alertId) {
  const state=load(); const row=state.alerts.find(a=>a.id===alertId && a.userId===userId && a.active);
  if(!row) return false; row.active=false; row.cancelledAt=isoNow(); save(state); return true;
}
export function addSnapshot(snapshot) {
  const productKey=clean(snapshot.productKey,300);
  const sourceId=clean(snapshot.sourceId,80), offerId=clean(snapshot.offerId,160);
  const currency=currencyCode(snapshot.currency||'EUR');
  const price=Number(snapshot.price ?? snapshot.effectiveCost);
  const shipping=Number(snapshot.shipping ?? 0), mandatoryFees=Number(snapshot.mandatoryFees ?? 0), taxes=Number(snapshot.taxes ?? 0), discount=Number(snapshot.discount ?? 0);
  if(!productKey || !sourceId || !offerId) throw new Error('invalid_snapshot_identity');
  if(![price,shipping,mandatoryFees,taxes,discount].every(n=>Number.isFinite(n)&&n>=0)) throw new Error('invalid_snapshot_amount');
  // Never trust a client-supplied effectiveCost when a price breakdown is available.
  const effectiveCost=Math.max(0,Math.round((price+shipping+mandatoryFees+taxes-discount+Number.EPSILON)*100)/100);
  const row={...snapshot,productKey,sourceId,offerId,price,shipping,mandatoryFees,taxes,discount,effectiveCost,currency,costIsEstimate:snapshot.costIsEstimate===true,id:crypto.randomUUID(),recordedAt:isoNow()};
  const state=load(); state.snapshots.push(row); save(state); return row;
}
export function getPriceHistory(productKey, limit=90) {
  const key=clean(productKey,300); const count=Math.min(365,Math.max(1,Number(limit)||90));
  return load().snapshots.filter(s=>s.productKey===key).sort((a,b)=>new Date(a.recordedAt)-new Date(b.recordedAt)).slice(-count);
}
export function addClick(click) {
  const sourceId=clean(click.sourceId,80), offerId=clean(click.offerId,160);
  if(!sourceId || !offerId) throw new Error('invalid_click');
  let destination;
  try { destination=new URL(String(click.destinationUrl)); } catch { throw new Error('invalid_destination_url'); }
  if(!['https:','http:'].includes(destination.protocol) || destination.username || destination.password) throw new Error('invalid_destination_url');
  const state=load(); const row={id:crypto.randomUUID(),userId:click.userId,sourceId,offerId,clickToken:crypto.randomUUID(),destinationUrl:destination.toString(),createdAt:isoNow()};
  state.clicks.push(row); save(state); return row;
}
export function getEntitlement(userId) { return load().entitlements[userId] || {active:false,source:'none'}; }
export function setEntitlement(userId, entitlement) {
  const state=load(); const status=clean(entitlement.status || (entitlement.active?'active':'inactive'),24).toLowerCase();
  if(!['active','inactive','grace_period','cancelled','expired','pending'].includes(status)) throw new Error('invalid_entitlement_status');
  state.entitlements[userId]={...entitlement,status,active:status==='active'||status==='grace_period',updatedAt:isoNow()}; save(state); return state.entitlements[userId];
}
export function evaluateAlerts({maxSnapshotAgeMs=24*3600*1000}={}) {
  const state=load(); let triggered=0; const now=Date.now();
  for (const alert of state.alerts.filter(a=>a.active)) {
    const snapshots=state.snapshots.filter(s=>s.productKey===alert.productKey && s.currency===alert.currency && s.costIsEstimate!==true && new Date(s.recordedAt).getTime()>=new Date(alert.createdAt).getTime() && now-new Date(s.recordedAt).getTime()<=maxSnapshotAgeMs);
    if(!snapshots.length) continue;
    const latest=snapshots.reduce((a,b)=>new Date(a.recordedAt)>new Date(b.recordedAt)?a:b);
    if(Number(latest.effectiveCost)<=Number(alert.targetPrice)) {
      alert.active=false; alert.triggeredAt=isoNow();
      state.notifications.push({id:crypto.randomUUID(),userId:alert.userId,alertId:alert.id,type:'PRICE_DROP',productKey:alert.productKey,effectiveCost:Number(latest.effectiveCost),currency:alert.currency,createdAt:isoNow(),deliveredAt:null,readAt:null});
      triggered++;
    }
  }
  save(state); return {triggered};
}
export function listNotifications(userId) { return load().notifications.filter(n=>n.userId===userId).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)); }
export function markNotificationRead(userId, notificationId) {
  const state=load(); const row=state.notifications.find(n=>n.id===notificationId && n.userId===userId);
  if(!row) return false; row.readAt=row.readAt||isoNow(); save(state); return true;
}

export async function healthCheck() { return {ok:true,storage:'json-reference'}; }

// Storage selector. JSON is retained only for local development/tests; DATABASE_URL selects PostgreSQL.
const implementation = process.env.DATABASE_URL
  ? await import('./postgres-store.mjs')
  : await import('./json-store.mjs');

export const storageKind = process.env.DATABASE_URL ? 'postgresql' : 'json-reference';
export const healthCheck = (...args) => implementation.healthCheck(...args);
export const createUser = (...args) => implementation.createUser(...args);
export const login = (...args) => implementation.login(...args);
export const authenticate = (...args) => implementation.authenticate(...args);
export const revokeSession = (...args) => implementation.revokeSession(...args);
export const deleteUser = (...args) => implementation.deleteUser(...args);
export const createAlert = (...args) => implementation.createAlert(...args);
export const listAlerts = (...args) => implementation.listAlerts(...args);
export const listMonitorableAlerts = (...args) => implementation.listMonitorableAlerts(...args);
export const markAlertChecked = (...args) => implementation.markAlertChecked(...args);
export const deactivateAlert = (...args) => implementation.deactivateAlert(...args);
export const addSnapshot = (...args) => implementation.addSnapshot(...args);
export const getPriceHistory = (...args) => implementation.getPriceHistory(...args);
export const addClick = (...args) => implementation.addClick(...args);
export const getEntitlement = (...args) => implementation.getEntitlement(...args);
export const setEntitlement = (...args) => implementation.setEntitlement(...args);
export const evaluateAlerts = (...args) => implementation.evaluateAlerts(...args);
export const listNotifications = (...args) => implementation.listNotifications(...args);
export const markNotificationRead = (...args) => implementation.markNotificationRead(...args);

/** Refresh only explicitly tracked products. This deliberately avoids building a permanent catalog. */
export async function refreshAlertPrices({listAlerts, markAlertChecked, search, addSnapshot, limit=20, concurrency=4}) {
  const alerts = await listAlerts({limit});
  const groups = new Map();
  for (const alert of alerts) {
    const query = String(alert.query || '').trim();
    if (!query) continue;
    const request = {
      query,
      category: String(alert.category || 'Tutte'),
      countryCode: String(alert.countryCode || 'IT'),
      currency: String(alert.currency || 'EUR'),
      maxResults: 30
    };
    const key = JSON.stringify([request.query, request.category, request.countryCode, request.currency]);
    if (!groups.has(key)) groups.set(key, {request, alerts: []});
    groups.get(key).alerts.push(alert);
  }

  const rows = [...groups.values()];
  let searches = 0, snapshotsAdded = 0, sourceFailures = 0, matchedAlerts = 0;
  for (let offset=0; offset<rows.length; offset+=Math.max(1,concurrency)) {
    await Promise.all(rows.slice(offset, offset+Math.max(1,concurrency)).map(async group => {
      let result = null;
      try {
        result = await search(group.request);
        searches++;
        sourceFailures += (result?.sources || []).filter(s => s.status !== 'ok').length;
      } catch {
        sourceFailures++;
      }
      for (const alert of group.alerts) {
        try {
          const matches = result?.offers?.filter(offer =>
            offer.normalizedProductKey === alert.productKey &&
            offer.currency === String(alert.currency || 'EUR').toUpperCase()
          ) || [];
          if (matches.length) matchedAlerts++;
          for (const offer of matches) {
            try {
              await addSnapshot({
                productKey: alert.productKey,
                sourceId: offer.sourceId,
                offerId: offer.id,
                title: offer.title,
                brand: offer.brand,
                model: offer.model,
                price: offer.price,
                shipping: offer.shipping,
                mandatoryFees: offer.mandatoryFees,
                taxes: offer.taxes,
                discount: offer.discount,
                currency: offer.currency,
                costIsEstimate: offer.costIsEstimate === true
              });
              snapshotsAdded++;
            } catch { /* One malformed offer must not block the rest of a monitoring run. */ }
          }
        } finally {
          try { await markAlertChecked(alert.id); } catch { /* Next run will retry if persistence failed. */ }
        }
      }
    }));
  }
  return {alertsConsidered: alerts.length, searchGroups: rows.length, searches, matchedAlerts, snapshotsAdded, sourceFailures};
}

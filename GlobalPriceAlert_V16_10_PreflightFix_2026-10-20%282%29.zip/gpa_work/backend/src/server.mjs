import http from 'node:http';
import crypto from 'node:crypto';
import {createUser, login, authenticate, revokeSession, deleteUser, createAlert, listAlerts, listMonitorableAlerts, markAlertChecked, deactivateAlert, addSnapshot, addClick, getEntitlement, setEntitlement, evaluateAlerts, listNotifications, markNotificationRead, getPriceHistory, healthCheck, storageKind} from './store.mjs';
import {refreshAlertPrices} from './monitoring.mjs';
import {SourceRegistry, dedupeOffers, groupOffersByProduct, createConfiguredSources} from './sources.mjs';
import {assessCompatibility} from './compatibility.mjs';

// Intentionally empty until authorized marketplace adapters are configured.
const registry = new SourceRegistry(createConfiguredSources());
const port = Number(process.env.PORT || 8787);
const internalKey = process.env.GPA_INTERNAL_KEY || '';
const rate = new Map();
const loginFailures = new Map();
const LIMIT = 1_000_000;
const json = (res, code, body) => {
  res.writeHead(code, {
    'content-type':'application/json; charset=utf-8',
    'cache-control':'no-store',
    'x-content-type-options':'nosniff',
    'referrer-policy':'no-referrer',
    'content-security-policy':"default-src 'none'; frame-ancestors 'none'"
  });
  res.end(JSON.stringify(body));
};
async function body(req) {
  const contentType=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();
  if(contentType!=='application/json') throw new Error('unsupported_media_type');
  let size=0; const chunks=[];
  for await (const chunk of req) {
    size+=chunk.length;
    if(size>LIMIT) { req.resume(); throw new Error('payload_too_large'); }
    chunks.push(chunk);
  }
  if(!size) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new Error('invalid_json'); }
}
function bearer(req) { const h=req.headers.authorization||''; return h.startsWith('Bearer ') ? h.slice(7) : ''; }
async function user(req) { return authenticate(bearer(req)); }
async function requireUser(req,res) { const id=await user(req); if(!id){json(res,401,{error:'unauthorized'}); return null;} return id; }
function requireInternal(req,res) {
  const supplied=String(req.headers['x-internal-key']||'');
  const a=Buffer.from(supplied), b=Buffer.from(internalKey);
  if(!internalKey || a.length!==b.length || !crypto.timingSafeEqual(a,b)){json(res,403,{error:'forbidden'}); return false;}
  return true;
}
function rateLimit(req,res) {
  const ip=req.socket.remoteAddress||'unknown'; const now=Date.now();
  let row=rate.get(ip)||{at:now,count:0};
  if(now-row.at>60000) row={at:now,count:0};
  row.count++; rate.set(ip,row);
  if(rate.size>10000) for(const [key,value] of rate) if(now-value.at>120000) rate.delete(key);
  if(row.count>120){json(res,429,{error:'rate_limited'});return false;}
  return true;
}
function checkLoginLimit(req,res) {
  const ip=req.socket.remoteAddress||'unknown'; const now=Date.now(); const row=loginFailures.get(ip);
  if(row && now-row.at<15*60*1000 && row.count>=10){json(res,429,{error:'login_rate_limited'});return false;}
  return true;
}
function recordLogin(req,success) {
  const ip=req.socket.remoteAddress||'unknown'; const now=Date.now();
  if(success){loginFailures.delete(ip);return;}
  const row=loginFailures.get(ip);
  loginFailures.set(ip,!row||now-row.at>=15*60*1000?{at:now,count:1}:{at:row.at,count:row.count+1});
  if(loginFailures.size>10000) for(const [key,value] of loginFailures) if(now-value.at>30*60*1000) loginFailures.delete(key);
}
function searchInput(input) {
  const query=String(input.query??'').trim().slice(0,200);
  const category=String(input.category??'Tutte').trim().slice(0,120);
  const countryCode=String(input.countryCode??'IT').toUpperCase();
  const currency=String(input.currency??'EUR').toUpperCase();
  const maxResults=Math.min(50,Math.max(1,Number(input.maxResults)||30));
  if(!query && (!category || category==='Tutte')) throw new Error('query_or_specific_category_required');
  if(!/^[A-Z]{2}$/.test(countryCode)) throw new Error('invalid_country_code');
  if(!/^[A-Z]{3}$/.test(currency)) throw new Error('invalid_currency');
  return {query,category,countryCode,currency,maxResults};
}

const server=http.createServer(async(req,res)=>{
  try {
    if(!rateLimit(req,res)) return;
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(req.method==='GET'&&url.pathname==='/health'){ const h=await healthCheck(); return json(res,h.ok?200:503,{...h,service:'global-price-alert-backend',version:'0.6.0',storage:storageKind,marketplaceSources:registry.sources.length}); }
    if(req.method==='GET'&&url.pathname==='/v1/sources') return json(res,200,{sourcesConfigured:registry.sources.length>0,configured:registry.sources.length,liveSearchAvailable:false,sources:registry.sources.map(s=>({id:s.id,status:'configured_not_verified'}))});
    if(req.method==='POST'&&url.pathname==='/v1/auth/register'){
      const x=await body(req);
      try{return json(res,201,await createUser(x.email,x.password));}
      catch(e){const code=e.message==='email_exists'?409:400;return json(res,code,{error:e.message});}
    }
    if(req.method==='POST'&&url.pathname==='/v1/auth/login'){
      if(!checkLoginLimit(req,res))return;
      const x=await body(req);
      try{const result=await login(x.email,x.password);recordLogin(req,true);return json(res,200,result);}
      catch{recordLogin(req,false);return json(res,401,{error:'invalid_credentials'});}
    }
    if(req.method==='POST'&&url.pathname==='/v1/auth/logout'){
      const uid=await requireUser(req,res);if(!uid)return;
      await revokeSession(bearer(req));
      return json(res,200,{ok:true});
    }
    if(req.method==='DELETE'&&url.pathname==='/v1/me'){
      const uid=await requireUser(req,res);if(!uid)return;
      await deleteUser(uid);
      return json(res,200,{ok:true,deleted:true});
    }
    if(req.method==='POST'&&url.pathname==='/v1/search'){
      const input=searchInput(await body(req));
      const result=await registry.searchDetailed(input);
      const offers=dedupeOffers(result.offers);
      return json(res,200,{queryId:crypto.randomUUID(),offers,products:groupOffersByProduct(offers),sourceCount:registry.sources.length,sourcesConfigured:registry.sources.length>0,sourceStatus:result.sources,liveSearchAvailable:result.sources.some(s=>s.status==='ok')});
    }
    if(req.method==='POST'&&url.pathname==='/v1/compatibility/check'){
      const x=await body(req);
      if(!x.target || typeof x.target!=='object' || !x.candidate || typeof x.candidate!=='object') return json(res,400,{error:'target_and_candidate_objects_required'});
      const result=assessCompatibility(x.target,x.candidate);
      return json(res,200,{...result,disclaimer:'La compatibilità è una valutazione basata solo sui dati forniti; verifica codici e specifiche con il produttore o venditore prima dell’acquisto.'});
    }
    if(req.method==='GET'&&url.pathname==='/v1/price-history'){
      const productKey=url.searchParams.get('productKey')||'';
      if(!productKey.trim()||productKey.length>300) return json(res,400,{error:'valid_productKey_required'});
      const limit=Number(url.searchParams.get('limit')||90);
      if(!Number.isInteger(limit)||limit<1||limit>365) return json(res,400,{error:'limit_must_be_1_to_365'});
      return json(res,200,{productKey,history:await getPriceHistory(productKey,limit)});
    }
    if(req.method==='POST'&&url.pathname==='/v1/alerts'){
      const uid=await requireUser(req,res);if(!uid)return;
      const x=await body(req);
      try{return json(res,201,await createAlert({userId:uid,productKey:x.productKey,targetPrice:x.targetPrice,currency:x.currency||'EUR',query:x.query||'',category:x.category||'Tutte',countryCode:x.countryCode||'IT'}));}
      catch(e){return json(res,400,{error:e.message});}
    }
    if(req.method==='GET'&&url.pathname==='/v1/alerts'){
      const uid=await requireUser(req,res);if(!uid)return;
      return json(res,200,{alerts:await listAlerts(uid)});
    }
    const alertMatch=url.pathname.match(/^\/v1\/alerts\/([0-9a-f-]{36})$/i);
    if(req.method==='DELETE'&&alertMatch){
      const uid=await requireUser(req,res);if(!uid)return;
      return await deactivateAlert(uid,alertMatch[1])?json(res,200,{ok:true}):json(res,404,{error:'alert_not_found'});
    }
    if(req.method==='GET'&&url.pathname==='/v1/notifications'){
      const uid=await requireUser(req,res);if(!uid)return;
      return json(res,200,{notifications:await listNotifications(uid)});
    }
    const notificationMatch=url.pathname.match(/^\/v1\/notifications\/([0-9a-f-]{36})\/read$/i);
    if(req.method==='POST'&&notificationMatch){
      const uid=await requireUser(req,res);if(!uid)return;
      return await markNotificationRead(uid,notificationMatch[1])?json(res,200,{ok:true}):json(res,404,{error:'notification_not_found'});
    }
    if(req.method==='POST'&&url.pathname==='/v1/affiliate/click'){
      const uid=await requireUser(req,res);if(!uid)return;
      const x=await body(req);
      try{return json(res,201,await addClick({...x,userId:uid}));}
      catch(e){return json(res,400,{error:e.message});}
    }
    if(req.method==='GET'&&url.pathname==='/v1/me/entitlement'){
      const uid=await requireUser(req,res);if(!uid)return;
      return json(res,200,await getEntitlement(uid));
    }
    if(req.method==='POST'&&url.pathname==='/v1/internal/price-snapshots'){
      if(!requireInternal(req,res))return;
      try{return json(res,201,await addSnapshot(await body(req)));}
      catch(e){return json(res,400,{error:e.message});}
    }
    if(req.method==='POST'&&url.pathname==='/v1/internal/refresh-alerts'){
      if(!requireInternal(req,res))return;
      const result=await refreshAlertPrices({listAlerts:listMonitorableAlerts,markAlertChecked,search:request=>registry.searchDetailed(request),addSnapshot});
      return json(res,200,result);
    }
    if(req.method==='POST'&&url.pathname==='/v1/internal/evaluate-alerts'){
      if(!requireInternal(req,res))return;
      return json(res,200,await evaluateAlerts());
    }
    if(req.method==='POST'&&url.pathname==='/v1/internal/entitlement'){
      if(!requireInternal(req,res))return;
      const x=await body(req);if(!x.userId)return json(res,400,{error:'userId_required'});
      try{return json(res,200,await setEntitlement(x.userId,x.entitlement||{}));}
      catch(e){return json(res,400,{error:e.message});}
    }
    return json(res,404,{error:'not_found'});
  } catch(e){
    const code=e.message==='payload_too_large'?413:e.message==='unsupported_media_type'?415:e.message==='invalid_json'?400: e.message==='query_or_specific_category_required'||e.message==='invalid_country_code'||e.message==='invalid_currency'?400:500;
    return json(res,code,{error:code===500?'internal_error':e.message});
  }
});
server.listen(port,()=>console.log(`Global Price Alert backend listening on :${port}`));

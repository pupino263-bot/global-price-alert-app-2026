const normalize = value => String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '').trim();
const get = (obj, key) => obj?.attributes?.[key] ?? obj?.[key] ?? null;
const list = value => (Array.isArray(value) ? value : value == null ? [] : [value]).map(normalize).filter(Boolean);

/**
 * Conservative compatibility assessment. It never upgrades missing evidence to "confirmed".
 * Supported hard-fit fields: voltage, connector, diameter, length, width, height, size.
 */
export function assessCompatibility(target, candidate) {
  if (!target || typeof target !== 'object' || !candidate || typeof candidate !== 'object') {
    return {status: 'unknown', confidence: 0, evidence: ['Dati insufficienti per il controllo.']};
  }

  const targetPart = normalize(get(target, 'partNumber') || get(target, 'oemNumber'));
  const candidatePart = normalize(get(candidate, 'partNumber') || get(candidate, 'oemNumber'));
  if (targetPart && candidatePart && targetPart === candidatePart) {
    return {status: 'confirmed', confidence: 1, evidence: ['Codice ricambio/OEM identico.']};
  }

  const hardFields = ['voltage', 'connector', 'diameter', 'length', 'width', 'height', 'size'];
  const mismatches = [];
  const matches = [];
  for (const field of hardFields) {
    const a = normalize(get(target, field));
    const b = normalize(get(candidate, field));
    if (!a || !b) continue;
    if (a !== b) mismatches.push(`${field}: richiesto ${String(get(target, field))}, trovato ${String(get(candidate, field))}`);
    else matches.push(`${field} corrispondente (${String(get(target, field))})`);
  }
  if (mismatches.length) {
    return {status: 'incompatible', confidence: Math.min(0.99, 0.85 + mismatches.length * 0.03), evidence: mismatches};
  }

  const requiredModel = normalize(get(target, 'vehicleModel') || get(target, 'deviceModel') || get(target, 'model'));
  const candidateModels = list(get(candidate, 'compatibleModels') || get(candidate, 'fitmentModels'));
  if (requiredModel && candidateModels.includes(requiredModel)) {
    return {status: 'confirmed', confidence: 0.96, evidence: [`Modello dichiarato compatibile: ${String(get(target, 'vehicleModel') || get(target, 'deviceModel') || get(target, 'model'))}.`]};
  }
  if (requiredModel && candidateModels.length && get(candidate, 'fitmentComplete') === true) {
    return {status: 'incompatible', confidence: 0.9, evidence: ['Il catalogo fitment dichiarato completo non include il modello richiesto.']};
  }

  if (matches.length >= 2) return {status: 'likely', confidence: Math.min(0.84, 0.55 + matches.length * 0.08), evidence: matches};
  if (targetPart && candidatePart && targetPart !== candidatePart) {
    return {status: 'unknown', confidence: 0.35, evidence: ['I codici differiscono; ciò da solo non prova incompatibilità o equivalenza.']};
  }
  return {status: 'unknown', confidence: matches.length ? 0.3 : 0, evidence: matches.length ? matches : ['Nessuna evidenza sufficiente per confermare la compatibilità.']};
}

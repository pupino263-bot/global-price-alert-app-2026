/** Authorized source adapter contract. Real marketplace adapters must be registered only after approval. */
export class ProductSource {
  constructor(id) { this.id = id; }
  async search(_request) { throw new Error(`Source ${this.id} is not configured`); }
}

const text = (value, max = 240) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const amount = (value, field) => {
  const n = Number(value ?? 0);
  if (!Number.isFinite(n) || n < 0) throw new Error(`invalid_${field}`);
  return Math.round((n + Number.EPSILON) * 100) / 100;
};

export class SourceRegistry {
  constructor(sources = [], {timeoutMs = 8000} = {}) {
    this.sources = sources;
    this.timeoutMs = timeoutMs;
  }

  async searchDetailed(request) {
    const outcomes = await Promise.all(this.sources.map(async source => {
      let timer;
      try {
        const result = await Promise.race([
          Promise.resolve().then(() => source.search(request)),
          new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('source_timeout')), this.timeoutMs); })
        ]);
        return {sourceId: source.id, status: 'ok', count: Array.isArray(result) ? result.length : 0, offers: Array.isArray(result) ? result : []};
      } catch (error) {
        return {sourceId: source.id, status: error?.message === 'source_timeout' ? 'timeout' : 'error', count: 0, offers: []};
      } finally {
        clearTimeout(timer);
      }
    }));
    const offers = [];
    for (const row of outcomes) {
      for (const offer of row.offers) {
        try { offers.push(normalizeOffer({...offer, sourceId: offer.sourceId || row.sourceId})); }
        catch { /* A malformed offer is discarded without failing other sources. */ }
      }
    }
    const maxResults = Math.min(50, Math.max(1, Number(request.maxResults) || 30));
    return {offers: dedupeOffers(offers).slice(0, maxResults), sources: outcomes.map(({sourceId,status,count}) => ({sourceId,status,count}))};
  }

  async searchAll(request) { return (await this.searchDetailed(request)).offers; }
}

function isValidGtin(value) {
  const raw = text(value, 32);
  // Permit human-readable spaces/hyphens, but never silently strip arbitrary letters.
  if (!/^[0-9\s-]+$/.test(raw)) return false;
  const digits = raw.replace(/\D/g, '');
  // GS1 GTIN lengths are 8, 12, 13 or 14 digits; the final digit is a check digit.
  if (![8, 12, 13, 14].includes(digits.length)) return false;
  const body = digits.slice(0, -1);
  let sum = 0;
  for (let offset = 0; offset < body.length; offset++) {
    const digit = Number(body[body.length - 1 - offset]);
    sum += digit * (offset % 2 === 0 ? 3 : 1);
  }
  const expected = (10 - (sum % 10)) % 10;
  return expected === Number(digits.at(-1));
}

const VARIANT_ATTRIBUTE_KEYS = [
  'color', 'colour', 'colore', 'size', 'taglia', 'storage', 'capacity', 'memory',
  'voltage', 'connector', 'diameter', 'length', 'width', 'height', 'packSize', 'quantity', 'modelYear'
];
const COLOR_ALIASES = new Map([
  ['black','black'],['white','white'],['red','red'],['blue','blue'],['green','green'],['grey','grey'],['gray','grey'],['silver','silver'],['gold','gold'],['pink','pink'],['purple','purple'],['yellow','yellow'],['orange','orange'],['brown','brown'],['navy','navy'],['transparent','transparent'],['clear','transparent'],['graphite','graphite'],['midnight','midnight'],
  ['nero','black'],['noir','black'],['negro','black'],['schwarz','black'],
  ['bianco','white'],['blanc','white'],['blanco','white'],['weiss','white'],['weiß','white'],
  ['rosso','red'],['rouge','red'],['rojo','red'],
  ['blu','blue'],['bleu','blue'],['azul','blue'],
  ['verde','green'],['vert','green'],['grun','green'],['grün','green'],
  ['grigio','grey'],['gris','grey'],['grau','grey'],['argento','silver'],['argent','silver'],
  ['oro','gold'],['dorato','gold'],['dore','gold'],['dorado','gold']
]);

function normalizeVariantText(value) {
  let normalized = String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  normalized = normalized.replace(/(\d+(?:[.,]\d+)?)\s*(gb|tb|mb|mah|ml|cl|l|w|kw|v|mv|mm|cm|m|inch|in|oz|kg|g|pcs|pc|pezzi|pack)\b/g, (_, n, unit) => `${n.replace(',', '.')}${unit}`);
  const tokens = normalized.match(/[a-z0-9]+(?:\.[0-9]+)?/g) || [];
  return [...new Set(tokens.map(token => COLOR_ALIASES.get(token) || token))].sort().join('-');
}

function inferVariantSignature(o) {
  const explicit = [];
  if (o.variant) explicit.push(o.variant);
  const attributes = o.attributes && typeof o.attributes === 'object' && !Array.isArray(o.attributes) ? o.attributes : {};
  for (const key of VARIANT_ATTRIBUTE_KEYS) {
    const value = attributes[key] ?? o[key];
    if (value !== undefined && value !== null && String(value).trim()) explicit.push(String(value));
  }
  // Add conservative title inference even when an explicit color/size is supplied,
  // so one source's "Black" variant can still match another source's "128 GB Black" title.
  const title = text(o.title, 240);
  const inferred = [];
  for (const match of title.matchAll(/\b\d+(?:[.,]\d+)?\s*(?:gb|tb|mb|mah|ml|cl|kw|w|v|mv|mm|cm|inch|in|oz|kg|g|pcs|pezzi|pack)\b/gi)) inferred.push(match[0]);
  const lower = title.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  for (const color of COLOR_ALIASES.keys()) if (new RegExp(`\\b${color}\\b`, 'i').test(lower)) inferred.push(color);
  const sizeMatch = title.match(/\b(?:xs|s|m|l|xl|xxl|xxxl|2xl|3xl)\b/i);
  if (sizeMatch) inferred.push(sizeMatch[0]);
  return normalizeVariantText([...explicit, ...inferred].join(' '));
}

function productKey(o) {
  const rawGtin = text(o.gtin, 32);
  const gtin = rawGtin.replace(/\D/g, '');
  if (isValidGtin(rawGtin)) return `gtin:${gtin}`;
  const brand = text(o.brand, 100).toLowerCase();
  const model = text(o.model, 100).toLowerCase();
  const variant = inferVariantSignature(o);
  if (brand && model) return `brand-model:${brand}|${model}${variant ? `|variant:${variant}` : ''}`;
  const title = text(o.title, 240).toLowerCase();
  const category = text(o.category, 120).toLowerCase();
  if (title) return `title:${category}|${title}`;
  return `source:${text(o.sourceId, 80)}|${text(o.id, 120)}`;
}

export function normalizeOffer(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o)) throw new Error('invalid_offer');
  const price = amount(o.price, 'price');
  const shipping = amount(o.shipping, 'shipping');
  const mandatoryFees = amount(o.mandatoryFees, 'mandatory_fees');
  const discount = amount(o.discount, 'discount');
  const taxes = amount(o.taxes, 'taxes');
  if (discount > price + shipping + mandatoryFees + taxes) throw new Error('invalid_discount_exceeds_gross_total');
  const currency = String(o.currency || 'EUR').trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error('invalid_currency');
  const id = text(o.id, 160);
  const sourceId = text(o.sourceId, 80);
  const title = text(o.title, 240);
  if (!id || !sourceId || !title) throw new Error('missing_offer_identity');
  const effectiveCost = Math.round((price + shipping + mandatoryFees + taxes - discount + Number.EPSILON) * 100) / 100;
  const costIsEstimate = o.costIsEstimate === true || o.shippingKnown !== true || o.taxesKnown !== true || o.mandatoryFeesKnown !== true;
  const normalizedProductKey = productKey({...o, title, sourceId, id});
  const variantSignature = inferVariantSignature({...o, title});
  const productFamilyKey = (text(o.brand, 100) && text(o.model, 100)) ? `brand-model:${text(o.brand, 100).toLowerCase()}|${text(o.model, 100).toLowerCase()}` : `title:${text(o.category, 120).toLowerCase()}|${title.toLowerCase()}`;
  let safeUrl = '';
  if (o.url) {
    try {
      const parsed = new URL(String(o.url));
      if (['https:', 'http:'].includes(parsed.protocol) && !parsed.username && !parsed.password) safeUrl = parsed.toString();
    } catch { /* Invalid URLs are omitted from the offer. */ }
  }
  return {...o, id, sourceId, title, brand:text(o.brand,100), model:text(o.model,100), category:text(o.category,120), variantSignature, productFamilyKey, currency, price, shipping, mandatoryFees, taxes, discount, effectiveCost, costIsEstimate, url:safeUrl, normalizedProductKey};
}

/**
 * Removes duplicate records from the same source, but deliberately preserves the
 * same product offered by different stores. A comparator must show all alternatives.
 */
export function dedupeOffers(offers) {
  const byOffer = new Map();
  for (const raw of offers) {
    let offer;
    try { offer = normalizeOffer(raw); } catch { continue; }
    const locator = offer.url || offer.id;
    const key = `${offer.sourceId}|${locator}`;
    const old = byOffer.get(key);
    if (!old || offer.effectiveCost < old.effectiveCost) byOffer.set(key, offer);
  }
  return [...byOffer.values()].sort((a,b) => a.currency.localeCompare(b.currency) || Number(a.costIsEstimate)-Number(b.costIsEstimate) || a.effectiveCost - b.effectiveCost || a.sourceId.localeCompare(b.sourceId));
}

export function groupOffersByProduct(offers) {
  const groups = new Map();
  for (const offer of offers) {
    const key = offer.normalizedProductKey || productKey(offer);
    if (!groups.has(key)) groups.set(key, {productKey:key, productFamilyKey:offer.productFamilyKey || key, variantSignature:offer.variantSignature || '', title:offer.title, brand:offer.brand || '', model:offer.model || '', offers:[]});
    groups.get(key).offers.push(offer);
  }
  const rows=[...groups.values()].map(group => {
    const currencies=[...new Set(group.offers.map(o=>o.currency))].sort();
    const byCurrency={};
    for(const currency of currencies) {
      const inCurrency=group.offers.filter(o=>o.currency===currency);
      const complete=inCurrency.filter(o=>!o.costIsEstimate);
      const comparable=complete.length?complete:inCurrency;
      byCurrency[currency]={bestEffectiveCost:Math.min(...comparable.map(o=>o.effectiveCost)),hasCompleteCost:complete.length>0};
    }
    return {
      ...group,
      currency:currencies.length===1?currencies[0]:null,
      offers:group.offers.sort((a,b) => a.currency.localeCompare(b.currency) || Number(a.costIsEstimate)-Number(b.costIsEstimate) || a.effectiveCost - b.effectiveCost),
      // A single numeric minimum across currencies would be false precision; expose per-currency minima instead.
      bestEffectiveCost:currencies.length===1?byCurrency[currencies[0]].bestEffectiveCost:null,
      bestEffectiveCostByCurrency:byCurrency,
      hasCompleteCost:group.offers.some(o => !o.costIsEstimate)
    };
  });
  return rows.sort((a,b) => {
    if(a.currency && b.currency && a.currency===b.currency) return a.bestEffectiveCost-b.bestEffectiveCost;
    if(a.currency && b.currency) return a.currency.localeCompare(b.currency);
    return a.productKey.localeCompare(b.productKey);
  });
}

/**
 * eBay Browse API adapter. Uses server-side application credentials only; never put
 * EBAY_CLIENT_SECRET in the Android app. Production access may require eBay approval.
 */
export class EbayBrowseSource extends ProductSource {
  constructor({clientId, clientSecret, environment='production', marketplaceId='EBAY_IT', scope='https://api.ebay.com/oauth/api_scope', fetchImpl=fetch}={}) {
    super('ebay');
    this.clientId=String(clientId||'').trim();
    this.clientSecret=String(clientSecret||'').trim();
    this.environment=environment==='sandbox'?'sandbox':'production';
    this.defaultMarketplaceId=marketplaceId;
    this.scope=scope;
    this.fetchImpl=fetchImpl;
    this.token=null;
    this.tokenExpiresAt=0;
  }
  get isConfigured() { return Boolean(this.clientId && this.clientSecret); }
  get apiHost() { return this.environment==='sandbox'?'https://api.sandbox.ebay.com':'https://api.ebay.com'; }
  async accessToken() {
    if(!this.isConfigured) throw new Error('ebay_credentials_missing');
    if(this.token && Date.now()<this.tokenExpiresAt-60_000) return this.token;
    const basic=Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');
    const response=await this.fetchImpl(`${this.apiHost}/identity/v1/oauth2/token`,{
      method:'POST',headers:{Authorization:`Basic ${basic}`,'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},
      body:new URLSearchParams({grant_type:'client_credentials',scope:this.scope}).toString(),signal:AbortSignal.timeout(7000)
    });
    if(!response.ok) throw new Error(`ebay_oauth_http_${response.status}`);
    const data=await response.json();
    if(!data.access_token || !Number.isFinite(Number(data.expires_in))) throw new Error('ebay_oauth_invalid_response');
    this.token=String(data.access_token); this.tokenExpiresAt=Date.now()+Number(data.expires_in)*1000;
    return this.token;
  }
  async search(request) {
    if(!this.isConfigured) throw new Error('ebay_credentials_missing');
    const q=text(request.query,200);
    if(!q) throw new Error('ebay_keyword_required');
    const marketMap={IT:'EBAY_IT',US:'EBAY_US',GB:'EBAY_GB',UK:'EBAY_GB',DE:'EBAY_DE',FR:'EBAY_FR',ES:'EBAY_ES',CA:'EBAY_CA',AU:'EBAY_AU',NL:'EBAY_NL',PL:'EBAY_PL'};
    const marketplaceId=marketMap[String(request.countryCode||'IT').toUpperCase()]||this.defaultMarketplaceId;
    const params=new URLSearchParams({q,limit:String(Math.min(50,Math.max(1,Number(request.maxResults)||30)))});
    const token=await this.accessToken();
    const response=await this.fetchImpl(`${this.apiHost}/buy/browse/v1/item_summary/search?${params}`,{
      headers:{Authorization:`Bearer ${token}`,Accept:'application/json','X-EBAY-C-MARKETPLACE-ID':marketplaceId},signal:AbortSignal.timeout(7000)
    });
    if(!response.ok) throw new Error(`ebay_search_http_${response.status}`);
    const data=await response.json();
    return (Array.isArray(data.itemSummaries)?data.itemSummaries:[]).map(item=>{
      const priceValue=Number(item.price?.value);
      const currency=String(item.price?.currency||'').toUpperCase();
      const options=Array.isArray(item.shippingOptions)?item.shippingOptions:[];
      const shippingRow=options.find(o=>o.shippingCost?.value!==undefined || String(o.shippingCostType||'').toUpperCase()==='FREE');
      const shippingValue=shippingRow?.shippingCost?.value;
      const shippingCurrency=String(shippingRow?.shippingCost?.currency||currency).toUpperCase();
      const free=String(shippingRow?.shippingCostType||'').toUpperCase()==='FREE';
      const shippingKnown=Boolean(shippingRow && (free || (Number.isFinite(Number(shippingValue)) && shippingCurrency===currency)));
      const shipping=free?0:(shippingKnown?Number(shippingValue):0);
      if(!item.itemId || !item.title || !Number.isFinite(priceValue) || priceValue<0 || !/^[A-Z]{3}$/.test(currency)) return null;
      return {
        id:String(item.itemId),sourceId:this.id,title:text(item.title,240),brand:text(item.brand||item.itemBrand,100),model:text(item.mpn||item.model,100),
        category:text(item.categories?.[0]?.categoryName||request.category,120),gtin:text(item.gtin,32),price:priceValue,shipping,shippingKnown,
        mandatoryFees:0,mandatoryFeesKnown:false,taxes:0,taxesKnown:false,discount:0,currency,url:item.itemWebUrl||'',
        condition:text(item.condition,80),availability:text(item.estimatedAvailabilityStatus,100),costIsEstimate:true
      };
    }).filter(Boolean);
  }
}

export function createConfiguredSources(env=process.env) {
  const sources=[];
  const ebay=new EbayBrowseSource({clientId:env.EBAY_CLIENT_ID,clientSecret:env.EBAY_CLIENT_SECRET,environment:env.EBAY_ENV||'production',marketplaceId:env.EBAY_MARKETPLACE_ID||'EBAY_IT',scope:env.EBAY_SCOPE||'https://api.ebay.com/oauth/api_scope'});
  if(ebay.isConfigured) sources.push(ebay);
  return sources;
}

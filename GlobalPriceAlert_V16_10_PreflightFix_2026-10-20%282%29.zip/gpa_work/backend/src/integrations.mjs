/** Production integration contracts. These intentionally fail closed until provider credentials are configured. */
export class MarketplaceAdapter {
  constructor({id, baseUrl}) { this.id=id; this.baseUrl=baseUrl; }
  async search(_request) { throw new Error(`marketplace_not_configured:${this.id}`); }
}

export class AffiliateAdapter {
  constructor({id}) { this.id=id; }
  buildTrackedUrl(destinationUrl, clickToken) { throw new Error(`affiliate_not_configured:${this.id}`); }
}

export class BillingVerifier {
  async verifyPurchase(_payload) { throw new Error('google_play_billing_not_configured'); }
}

export class PushProvider {
  async send(_notification) { throw new Error('push_provider_not_configured'); }
}

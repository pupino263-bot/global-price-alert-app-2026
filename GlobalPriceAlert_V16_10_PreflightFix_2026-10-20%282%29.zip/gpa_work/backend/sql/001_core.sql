-- PostgreSQL production schema. Product offers are fetched dynamically; this is not a full catalog.
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS alerts (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_key TEXT NOT NULL,
  target_price NUMERIC(14,2) NOT NULL CHECK (target_price > 0),
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  triggered_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS alerts_active_product_idx ON alerts(product_key,currency) WHERE active=true;
CREATE INDEX IF NOT EXISTS alerts_user_active_idx ON alerts(user_id,created_at DESC) WHERE active=true;

CREATE TABLE IF NOT EXISTS price_snapshots (
  id UUID PRIMARY KEY,
  product_key TEXT NOT NULL,
  source_id TEXT NOT NULL,
  offer_id TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  brand TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  price NUMERIC(14,2) NOT NULL CHECK (price >= 0),
  shipping NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (shipping >= 0),
  mandatory_fees NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (mandatory_fees >= 0),
  discount NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  effective_cost NUMERIC(14,2) NOT NULL CHECK (effective_cost >= 0),
  currency CHAR(3) NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS price_snapshots_product_time ON price_snapshots(product_key,currency,recorded_at DESC);
CREATE INDEX IF NOT EXISTS price_snapshots_retention_idx ON price_snapshots(recorded_at);

CREATE TABLE IF NOT EXISTS affiliate_clicks (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  source_id TEXT NOT NULL,
  offer_id TEXT NOT NULL,
  click_token TEXT NOT NULL UNIQUE,
  destination_url TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS affiliate_clicks_created_idx ON affiliate_clicks(created_at DESC);

CREATE TABLE IF NOT EXISTS entitlements (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  provider_purchase_id TEXT,
  product_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('active','inactive','grace_period','cancelled','expired','pending')),
  expires_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Idempotent upgrade for databases created before the taxes field was added.
ALTER TABLE price_snapshots ADD COLUMN IF NOT EXISTS taxes NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (taxes >= 0);

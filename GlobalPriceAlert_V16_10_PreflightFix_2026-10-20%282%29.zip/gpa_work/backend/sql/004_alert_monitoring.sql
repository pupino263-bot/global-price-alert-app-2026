-- Search context lets the worker refresh only products users explicitly track.
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS query TEXT NOT NULL DEFAULT '';
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT 'Tutte';
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS country_code CHAR(2) NOT NULL DEFAULT 'IT';
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS last_checked_at TIMESTAMPTZ;

-- Backfill a best-effort search phrase for legacy GTIN/brand-model/title keys.
UPDATE alerts SET query=left(substring(product_key from 6),200) WHERE query='' AND product_key LIKE 'gtin:%';
UPDATE alerts SET query=left(replace(substring(product_key from 13),'|',' '),200) WHERE query='' AND product_key LIKE 'brand-model:%';
UPDATE alerts SET query=left(replace(substring(product_key from 7),'|',' '),200) WHERE query='' AND product_key LIKE 'title:%';
CREATE INDEX IF NOT EXISTS alerts_monitoring_idx ON alerts(last_checked_at NULLS FIRST) WHERE active=true AND query<>'';

-- Estimated totals (for example unknown shipping/taxes) must not trigger a definitive price alert.
ALTER TABLE price_snapshots ADD COLUMN IF NOT EXISTS cost_is_estimate BOOLEAN NOT NULL DEFAULT false;

# Global Price Alert — deployment and release gates

## Implemented in reference code and tested locally
- [x] Account registration/login, scrypt password hashing, bearer sessions
- [x] User-scoped alerts, alert cancellation, alert evaluation and account deletion endpoint
- [x] Price-history endpoint and notification read state
- [x] Search input validation and explicit source-availability reporting
- [x] Source timeout/failure isolation and malformed-offer rejection
- [x] Effective-cost normalization and preserving different stores' offers
- [x] HTTP(S)-only outbound destination validation
- [x] API/source integration tests included in `npm test`
- [x] PostgreSQL schema and OpenAPI contract updated to one consistent user model
- [x] Android alerts require account flow; demo fixtures are explicitly labelled
- [x] Release Gradle configuration requires a real HTTPS backend URL

## Not yet production-ready — requires code/infrastructure/credentials
- [x] Implement PostgreSQL repository selection and checksum-verified migrations
- [ ] Deploy PostgreSQL, run migrations including `004_alert_monitoring.sql`, and run full API tests against it; verify backup/restore and worker behavior (run a single worker until distributed leases are implemented)
- [ ] Deploy backend with HTTPS/TLS, secret manager, firewall/network controls
- [x] Implement first eBay Browse API adapter (credentials and access are still required)
- [x] Add tracked-alert refresh worker flow with query context, grouping, and 15-minute refresh throttle
- [x] Prevent estimated totals from triggering definitive alerts; complete totals remain required for an alert notification
- [ ] Obtain/confirm eBay production Buy API access, configure credentials in secret manager and test real responses/quotas/locale behavior
- [ ] Implement affiliate redirect/attribution/postback for approved networks
- [ ] Implement Google Play Billing purchase verification and subscription lifecycle handling
- [ ] Configure FCM and prove push delivery on a real device
- [ ] Implement secure persisted Android session storage and logout/session revocation
- [ ] Add localized Android UI strings for Italian, English, French, Spanish and German
- [ ] Add privacy policy, terms, support contact, consent/disclosure text and Play listing assets
- [ ] Configure release signing, build a signed AAB, install and regression-test on a device/emulator
- [ ] Add production monitoring, structured logs, alerting, backup/restore and retention jobs

## Release rule
Do not mark the app publishable until the selected launch scope has a real HTTPS backend, no demo offers presented as live, all privacy/legal disclosures are in place, and the signed AAB passes installation/regression checks. The reference JSON backend is not a production deployment.

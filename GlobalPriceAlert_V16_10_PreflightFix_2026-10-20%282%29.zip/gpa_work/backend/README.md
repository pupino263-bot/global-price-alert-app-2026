# Global Price Alert — backend reference v0.5

This is a **development/reference backend**, not a production deployment. It now includes stricter request validation, source isolation/timeouts, correct preservation of competing store offers, alert lifecycle/history endpoints, notification read state and safer outbound click validation.

## Requirements and local run

- Node.js 20 or newer
- Node package dependency: `pg` is required only for PostgreSQL mode; JSON reference mode tests need no database

```bash
npm test
GPA_INTERNAL_KEY='replace-with-a-long-random-secret' npm start
```

In another terminal, evaluate alerts once:

```bash
GPA_BASE_URL=http://127.0.0.1:8787 GPA_INTERNAL_KEY='same-secret' npm run worker:once
```

Or run the periodic worker (default every 60 seconds, minimum 15 seconds). It refreshes tracked searches before evaluating alerts; actual rechecks are throttled to once every 15 minutes per alert:

```bash
GPA_BASE_URL=http://127.0.0.1:8787 GPA_INTERNAL_KEY='same-secret' npm run worker
```

## PostgreSQL mode and migrations

The backend now selects a real PostgreSQL repository whenever `DATABASE_URL` is set. Without it, the JSON adapter remains active for local tests only. PostgreSQL mode uses the existing core/security schema plus idempotent migrations `003_snapshot_taxes.sql` and `004_alert_monitoring.sql`.

```bash
npm install
DATABASE_URL='postgres://gpa:URL_ENCODED_PASSWORD@localhost:5432/gpa' npm run migrate
DATABASE_URL='postgres://gpa:URL_ENCODED_PASSWORD@localhost:5432/gpa' GPA_INTERNAL_KEY='long-random-secret' npm start
```

The migration runner stores SHA-256 checksums and refuses to silently run a changed version of an already-applied migration. Back up the database before deploying migrations.

## eBay Browse API adapter

Set `EBAY_CLIENT_ID` and `EBAY_CLIENT_SECRET` on the backend only. The adapter obtains and caches an application token, uses the Browse API search endpoint, selects a marketplace from the requested country, and keeps listings with unknown shipping/tax/mandatory-fee details marked as estimates. Mixed-currency results are not compared by raw numeric amount; automatic FX conversion is not implemented yet. Never put the client secret in the Android app. Production access can require eBay approval; credentials alone do not prove the API is enabled.

## Important boundaries

- `/health` reports `storage: json-reference`: the current running API uses local JSON persistence. It is useful for local development and tests, **not for production scale or multi-instance deployment**.
- `/v1/sources` explicitly reports whether live sources are configured. The registry is empty until authorized adapters are configured; an empty result is not presented as a successful live marketplace search. The worker reuses one search for alerts sharing the same query/category/country/currency and stores snapshots only for exact normalized product-key matches. Non-GTIN matching now preserves common material variants (for example storage/color/size) in separate product groups. The Smart Compatibility endpoint is deliberately conservative: missing evidence returns `unknown`, and a differing part number alone is not treated as incompatibility. Existing alerts with GTIN, brand-model, or title keys receive a best-effort query backfill; legacy `source:` keys cannot be reliably reconstructed and need to be recreated from a search result.
- Android's demo offers are sample fixtures and must be labelled as demo. They are not scraped or current offers.
- Passwords are hashed with `scrypt`; session tokens are stored as SHA-256 hashes. The current in-process rate limiter is only a baseline and is not a distributed production control.
- Internal worker endpoints require `GPA_INTERNAL_KEY`; use a secret manager and network restrictions in deployment.
- `sql/001_core.sql` through `sql/004_alert_monitoring.sql` are applied by the migration runner. PostgreSQL mode is implemented, but it has not been tested against a live PostgreSQL instance in this workspace.

## Endpoints implemented in the reference server

- `POST /v1/auth/register`, `POST /v1/auth/login`
- `GET /v1/sources`, `POST /v1/search`, `POST /v1/compatibility/check`
- `GET /v1/price-history?productKey=...&limit=...`
- `POST /v1/alerts`, `GET /v1/alerts`, `DELETE /v1/alerts/{uuid}`
- `GET /v1/notifications`, `POST /v1/notifications/{uuid}/read`
- `POST /v1/affiliate/click`
- `DELETE /v1/me` (account deletion), `GET /v1/me/entitlement`
- Internal: `POST /v1/internal/price-snapshots`, `/refresh-alerts`, `/evaluate-alerts`, `/entitlement`

## Still requires real providers/infrastructure

Other marketplace APIs, affiliate network parameters/postbacks, Google Play purchase verification, FCM, live PostgreSQL deployment validation, HTTPS/reverse proxy, distributed rate limiting, monitoring and production secret management require provider approvals, credentials and deployment work. No live marketplace, purchase, affiliate sale or push delivery is claimed as connected.

# Global Price Alert V16.10 — release preflight localization fix

## Scope
Only `scripts/release-preflight.mjs` was changed to accept localized Android string resources when checking safety messages. Runtime behavior and app features were not changed.

## Fix
- Demo disclosure accepts `R.string.demo_mode` as well as legacy Italian literal wording.
- Premium billing disclosure accepts `R.string.premium_message` as well as legacy literal wording.
- Estimated-cost alert disclosure accepts a resource key containing `cost` or `estimate`, as well as legacy Italian literal wording.

## Verification
- `node scripts/release-preflight.mjs`: PASS (18 required files and static safety checks).
- `npm test` in `backend/`: PASS (5 test suites: sources, compatibility, mocked eBay adapter, monitoring, API integration).
- Android Gradle compilation / APK or AAB / device install: NOT RUN; this package has no Gradle wrapper and this environment has no Gradle installation.
- Live marketplace, production database, billing, ads, and Play publication: NOT tested.

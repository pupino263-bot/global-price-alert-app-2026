# Global Price Alert — V15

- Added Linux bootstrap script for Gradle 8.11.1 and Android SDK API 36 / Build Tools 36.0.0.
- Added Linux debug-build script and Windows PowerShell bootstrap script.
- Documented local setup and clarified that SDK downloads must run on a machine with Internet access.
- Added local Android tool downloads to `.gitignore`.
- Android toolchain download and full Gradle compilation are not marked as passed: outbound DNS/network is unavailable in the current build environment.

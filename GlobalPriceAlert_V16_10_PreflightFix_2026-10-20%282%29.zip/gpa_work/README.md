# Global Price Alert — Android + backend reference (V16.1 source package)

This package contains the Android MVP, domain/taxonomy code and a Node.js backend with selectable JSON-reference/PostgreSQL storage and an optional eBay Browse adapter. It advances the project toward release but is **not yet a production/publishable build**.

## What is implemented
- Android search/category UI and demo fallback explicitly labelled as sample data.
- Multi-store offer model, GTIN/brand-model/title normalization, per-source isolation and effective-cost calculation.
- Authenticated backend alert creation/list/cancellation, price history, notification list/read state, session logout and account deletion.
- Worker for periodic tracked-search refresh and alert evaluation; refreshes are grouped and throttled.
- PostgreSQL runtime repository, checksum-verified migrations, OpenAPI contract, backend tests and a CI workflow.
- Optional eBay Browse API adapter using server-side OAuth application credentials; unknown shipping/tax/fee details remain explicitly marked as estimates.
- Docker deployment example for PostgreSQL and API.
- Shared accessories/components/spares/consumables/compatible/professional subcategories across the taxonomy, including textile production, vaping/smokers accessories, jewellery, crafts/yarn, tattoo supplies, sports nutrition, HVAC/energy, automation, industrial machinery, plumbing/water treatment, and digital services.
- Release build configuration that refuses to proceed without a real HTTPS backend URL.

## Run backend tests

```bash
cd backend
npm test
```

## Important limitations
- No live store is currently connected in this package unless eBay credentials and required access are configured; demo offers are not current market prices. The eBay adapter is verified with mocked responses, not a live API account.
- Without `DATABASE_URL`, the backend uses local JSON reference storage and must not be deployed as a multi-instance production service. PostgreSQL mode is implemented but still needs live database validation.
- Android release has not been built/signed in this environment because Android SDK/Gradle are unavailable.
- Google Play Billing, ads, affiliate attribution, push notifications, production secrets/HTTPS, full localization and store/legal setup remain open.

See `TECHNICAL_STATUS.md` and `backend/DEPLOYMENT_CHECKLIST.md` for verified versus pending items.


## V9 Android session and notifications
The Android client now persists its bearer token only as AES-GCM ciphertext in private app storage, using a non-exportable Android Keystore key. Logout clears the local token even if the API is unreachable; HTTP 401 invalidates the local session. A minimal notification inbox reads the existing server notification endpoint and supports marking an item as read. These changes passed static integration checks, but still require full Gradle/Compose compilation and on-device verification.


## V10: Android CI build artifact
The GitHub Actions workflow provisions Android SDK 36, runs `gradle assembleDebug`, and uploads the debug APK. Push this project to its GitHub repository and inspect the Actions run to obtain that artifact. A successful debug APK is for testing only; the release build still requires a real HTTPS `GPA_BACKEND_URL`, signing configuration, and full regression. See `RELEASE_NOTES_V10.md` and `TECHNICAL_STATUS.md`.


## V11: release preflight gate
A static release preflight script checks required project files and protects key release rules (Android SDK targets, HTTPS backend guard, disabled backup, cross-category subcategory policy, demo labelling, Premium purchase disclosure, and CI artifact workflow). It runs in the Android CI job before Gradle compilation. Run locally with `node scripts/release-preflight.mjs` or `npm run preflight` from `backend/`. This gate is intentionally static and does not claim Android compilation or production integration tests.


## V14 verification pass

The CI backend job now runs the static release safety preflight in addition to the backend test suite, so release guard checks do not depend on the Android job starting. This is a workflow reliability improvement only; it does not imply a production release.

See `PRE_PUBLICATION_CHECKLIST.md` for the remaining external and device-dependent gates.

## Installazione locale di Gradle e Android SDK

Il progetto richiede Gradle **8.11.1**, JDK **17 o 21**, Android SDK **API 36** e Build Tools **36.0.0**. Per automatizzare l'installazione su una macchina con accesso a Internet:

- **Linux:** esegui `bash scripts/bootstrap-android-linux.sh`, poi `bash scripts/build-android-linux.sh`.
- **Windows PowerShell:** esegui `powershell -ExecutionPolicy Bypass -File .\scripts\bootstrap-android-windows.ps1`, poi avvia ` .android-tools\gradle-8.11.1\bin\gradle.bat assembleDebug` dalla cartella del progetto.
- **CI:** il workflow GitHub Actions installa già JDK, Android SDK API 36, Build Tools 36.0.0 e Gradle 8.11.1 e compila l'APK debug.

I bootstrap scaricano gli strumenti sulla macchina in cui vengono eseguiti; non includono l'SDK completo nel file ZIP. La compilazione release richiede inoltre un URL backend HTTPS reale (`GPA_BACKEND_URL`) e non sostituisce firma, test su dispositivo o verifiche di pubblicazione.


## V16.2 taxonomy coverage update — 17 October 2026

The taxonomy now includes explicit first-level categories for jewellery and costume jewellery; crafts, yarn and haberdashery; tattoo/body-art supplies; sports nutrition; heating, cooling and energy; home/industrial automation and networks; industrial machinery; plumbing and water treatment; and software/digital services. The static release preflight checks the minimum category count, required category labels and uniqueness of first-level names.

Latest local checks: `node scripts/release-preflight.mjs`, `cd backend && npm test`, Kotlin compilation of `Domain.kt`, `CategoryTaxonomy.kt` and `Architecture.kt`, and XML parsing all passed in the available workspace. Android Gradle build is still pending because Android SDK/Gradle downloads cannot be resolved from this environment; no APK/AAB is claimed.


## V16.3 — Smart Matching and total-cost safeguards (18 October 2026)
GTIN-based grouping checks standard length and GS1 check digit. If the code is invalid, identity falls back to brand/model/title instead of merging unrelated offers. A total is marked estimated unless shipping, taxes and mandatory fees are explicitly known; a discount cannot exceed the known gross amount. See `RELEASE_NOTES_V16_3_MATCHING_COST_SAFETY.md`.

# Global Price Alert — technical status V8

## Baseline implemented in previous iteration (V7)
- Added a PostgreSQL runtime repository selected by `DATABASE_URL`; JSON persistence remains only as a local reference/test adapter.
- Added a migration runner with per-file SHA-256 checksums and refusal to silently alter already-applied migrations.
- Added an idempotent `003_snapshot_taxes.sql` migration and aligned snapshot/offer/Android effective-cost formulas to include taxes when known.
- Corrected cross-currency comparison: offers are sorted/grouped by currency, and mixed-currency product groups expose per-currency minima instead of a misleading single numeric “best price”. Automatic FX conversion remains a separate pending service.
- Added the first real-provider adapter: eBay Browse API application-token flow, token cache, marketplace mapping, search response normalization, and safe handling of unknown shipping/tax/mandatory fees.
- Added mocked tests for eBay OAuth caching, marketplace header, listing mapping, missing shipping and estimated-cost sorting.
- Added Docker deployment example with PostgreSQL health check and private network; deployment remains a template, not a deployed service.

## Previously implemented in V6
- Hardened the reference backend request parser: content-type enforcement, malformed JSON response, early payload cap and security headers.
- Added failed-login throttling in addition to the general in-process request limiter.
- Added session revocation (`POST /v1/auth/logout`), account deletion (`DELETE /v1/me`) and preserved multiple sessions per user.
- Tightened email/password, currency, alert, snapshot and search input validation.
- Fixed product identity normalization: GTIN first, then brand+model, then title/category fallback.
- Fixed a comparator correctness issue: duplicate records from the same source are removed, but equivalent products sold by different stores remain visible as competing offers.
- Added source adapter timeouts, per-source status, malformed-offer isolation and source availability endpoint.
- Added price history endpoint, alert cancellation and notification read state.
- Price snapshot effective cost is calculated server-side from price + shipping + mandatory fees + known taxes - discount; a supplied mismatching effectiveCost is not trusted when a breakdown exists.
- Alert evaluation ignores snapshots captured before alert creation and ignores snapshots older than 24 hours.
- Added safe HTTP(S)-only affiliate destination validation (not affiliate network attribution or redirects).
- Consolidated the intended PostgreSQL schema on one `users` table and aligned the OpenAPI contract with implemented routes.
- Updated the worker to support periodic evaluation, one-shot mode, request timeout and graceful stop.
- Android now reads the normalized product key and full effective-cost breakdown, has a minimal account/register/login/logout flow, saves alerts to the backend only after authentication, and labels offline fixture results as demo rather than live prices.
- Added release-build guard: Android release requires a configured HTTPS backend URL; cleartext is enabled only in the debug manifest for local emulator development.
- Applied cross-cutting subcategories to every taxonomy branch and added the requested smokers/vaping category.
- Added a backend CI workflow and `.gitignore` for local data/secrets/build outputs.

## Verification performed in this environment
- `npm test` — PASS: source normalization, multi-store preservation, source failure isolation/timeouts, mocked eBay OAuth/token caching/response mapping, grouped alert refresh, exact product-key matching, estimated-cost propagation, API auth, alert lifecycle, stale-snapshot prevention, server-side cost calculation, price history, notifications, affiliate URL validation, request validation, oversized payload and logout.
- `node --check` on backend source and test files — PASS.
- PostgreSQL migration/repository source syntax — PASS; no live PostgreSQL server/client or Docker is available here, so SQL execution and transactional concurrency are NOT verified.
- eBay adapter uses mocked HTTP responses only; no real eBay credentials/API access were available.
- OpenAPI YAML parsed with PyYAML — PASS (15 paths).
- `kotlinc` compilation of Android's pure Kotlin domain/taxonomy/architecture files — PASS.
- Worker one-shot against a live local HTTP server — PASS; refresh and evaluation endpoints returned valid summaries without fabricating offers when no source was configured.
- Pure Kotlin domain/taxonomy/architecture compilation with `kotlinc` — PASS.
- OpenAPI and Docker Compose YAML parsing — PASS.
- ZIP integrity check is performed on the packaged artifact.

## Not verified / not complete
- Full Android Gradle build, Compose compilation, signed AAB and device tests: Android SDK/Gradle are unavailable in this environment; only pure Kotlin domain files were compiled.
- Live marketplace search: eBay Browse adapter is implemented but remains inactive until server-side client ID/secret are configured; production API access/approval and live response validation are still pending.
- Production persistence: PostgreSQL repository and migrations are implemented in code, but not verified against a live PostgreSQL instance or deployed database. JSON reference mode is not suitable for production.
- Production deployment, HTTPS, distributed rate limiting, secrets management, backups and monitoring.
- Affiliate network integration, sales postbacks and commission reconciliation.
- Google Play Billing purchase verification, subscription lifecycle, ads SDK and Premium entitlement UI integration.
- FCM push delivery and Android notification permission/device registration.
- Android session token persistence is now encrypted with an AES-GCM key held by Android Keystore (added in V9); runtime device/emulator verification is still pending.
- Full IT/EN/FR/ES/DE resource localization and manual language selector.
- Public account-deletion URL, privacy policy, terms, consent/disclosure text, support contact, store listing assets and Play Console review.

## Release rule
V8 is an improved development package, **not yet publishable**. The remaining hard blockers are: deploy the backend behind HTTPS, run PostgreSQL migrations/tests against a live database, configure and validate eBay production access (or another authorized live source), complete Android Gradle build/signing and device regression, and finish privacy/store requirements for the chosen launch scope.


## V8 monitoring block (2026-10-11)
- Added alert search context (`query`, category, country) so an alert can be refreshed dynamically without a permanent product catalog.
- Added PostgreSQL migration `004_alert_monitoring.sql` for refresh cadence and estimated-cost metadata, including best-effort backfill of legacy GTIN/brand-model/title alert queries.
- Added internal `/v1/internal/refresh-alerts`; worker now refreshes configured sources before evaluating alerts. Searches are grouped by identical context and throttled to 15 minutes per alert, with at most 20 refreshable alerts per run.
- Price snapshots preserve `costIsEstimate`; estimated totals remain in history but cannot trigger definitive price alerts.
- Android alert creation now sends the title/category/country context needed by the worker.
- Verified with Node tests: grouped refresh logic, exact product-key matching, snapshot creation, estimate propagation and API regression tests.
- Not verified: PostgreSQL migration/repository against a live database, live eBay requests, Android AAB build, push delivery, or production deployment. Legacy `source:` alert keys cannot be reliably converted to a search query; eBay estimates are intentionally excluded from definitive alert triggers. Run one worker instance until distributed leases are implemented.


## V9 Android account/session UX block (2026-10-12)
- Added `SessionVault`: backend bearer token is encrypted with AES/GCM/NoPadding using a non-exportable Android Keystore AES key; ciphertext alone is kept in private app SharedPreferences. Invalidated/corrupt ciphertext fails closed and clears the local session.
- `BackendClient` restores the encrypted token after process restart, persists successful logins, clears local credentials on logout even if the server is unreachable, clears after successful account deletion, and invalidates the local session when an authenticated request returns HTTP 401.
- Added authenticated notification-inbox calls in Android (`GET /v1/notifications`, `POST /v1/notifications/{id}/read`) and a basic UI dialog to review price alerts and mark notifications read.
- Password entry now uses `PasswordVisualTransformation` instead of displaying the password in clear text.
- Verified in this workspace: all backend tests pass; backend JavaScript syntax checks pass; pure Kotlin domain/taxonomy/architecture compilation passes; Android XML parses; static integration checks confirm Keystore encryption and notification API/UI wiring.
- Not verified: full Android Gradle/Compose build, Keystore behaviour on a real device/emulator, process-restart session restoration on device, notification UI/device testing. Android SDK/Gradle are unavailable in this workspace.
- Still pending: full IT/EN/FR/ES/DE localization and manual language selector; FCM token registration and push delivery; production database/API credentials; signed AAB and Play Console checks.


## V10 release-engineering block (2026-10-12)
- Hardened the existing GitHub Actions Android build job: it now explicitly installs Android SDK platform 36 and build-tools 36.0.0 before compiling, rather than relying on the runner's preinstalled SDK state.
- Added upload of the produced debug APK as a workflow artifact so a successful CI run yields an installable build for manual regression testing. This is a debug artifact, not a signed Play Store release.
- Backend regression suite was re-run locally for this iteration: PASS (all four Node test groups).
- Local full Android build remains unverified: this environment has Java and Kotlin compiler, but no Android SDK, no Gradle executable, and no Gradle wrapper in the project. The GitHub workflow can verify compilation only after the project is pushed to a repository and the workflow runs.
- Release blockers unchanged: real HTTPS backend + PostgreSQL validation/deployment, live authorized source credentials, FCM delivery, Billing/ads/affiliate integrations, IT/EN/FR/ES/DE UI localization, privacy/store materials, signed AAB and device regression.


## V11 release gate (2026-10-12)
- Added `scripts/release-preflight.mjs`, a static gate for required source files and release-critical safety/configuration invariants.
- Wired the preflight into the Android CI job before `assembleDebug`; backend package exposes `npm run preflight`.
- Verified locally: preflight passes; backend test suite passes; all backend and script `.mjs` files pass `node --check`.
- Not verified in this environment: remote GitHub Actions run, complete Gradle Android build, install/device regression, production PostgreSQL, live marketplace credentials, push delivery, Play Billing/ads, signed AAB.

## V12 alert correctness pass (2026-10-12)
- Android offer cards now disable alert creation when `costIsEstimate` is true or effective cost is non-finite/non-positive; UI explains the reason. This avoids creating alerts that cannot be triggered because backend evaluation deliberately rejects estimated snapshots.
- Static release preflight now checks the guard and explanation.
- Verified locally: preflight PASS; backend tests PASS (all four groups); JavaScript syntax checks PASS; Android XML parsing and pure Kotlin domain/taxonomy compilation can be repeated below.
- Still not verified: full Android Gradle/Compose build, device install/regression, signed AAB, live PostgreSQL, real marketplace access, push delivery, billing/ads/affiliate integrations, full localization and Play Console compliance.

## V13 verification refresh (2026-10-12)
- Re-ran `npm test`: PASS (all four backend test groups).
- Re-ran `npm run preflight`: PASS (13 required files and Android release safety guards).
- Re-ran Node syntax checks across backend source/tests and release preflight: PASS.
- Recompiled pure Kotlin domain/taxonomy/architecture files with `kotlinc`: PASS.
- Parsed Android manifest and styles XML: PASS; V12 ZIP integrity: PASS.
- This is a verification/documentation refresh, not a signed release. Full Gradle/Compose build and device testing remain unverified because Android SDK and Gradle are unavailable in this environment. All production blockers above remain open.


## V16.3 verification pass — 18 October 2026
- Added GS1 GTIN check-digit validation for GTIN-8/12/13/14 and fallback identity for invalid codes.
- Cost completeness now fails closed when shipping/taxes/mandatory fees are not explicitly known; over-large discounts are rejected.
- Local backend test suite and static preflight pass after the change. These checks do not replace Android Gradle build, live API/database verification or device tests.

## Incremental update — 2026-10-19 (V16.4)

- Non-GTIN product identity now adds a conservative material-variant signature (common capacity units, color aliases and size tokens) while exposing a shared `productFamilyKey`; this prevents different storage/color/size variants from being ranked as the same exact offer group.
- Added `backend/src/compatibility.mjs` and `POST /v1/compatibility/check`. The assessment preserves `unknown` when evidence is insufficient, confirms exact part/OEM code matches, and flags known hard attribute mismatches.
- Backend package/API version bumped to 0.6.0.
- Verified `npm test --prefix backend`, static release preflight, and `node --check` for all backend and script `.mjs` files.
- Not verified: Android Gradle build, APK/AAB, live eBay credentials, production PostgreSQL, push, billing, ads or affiliate sale attribution.

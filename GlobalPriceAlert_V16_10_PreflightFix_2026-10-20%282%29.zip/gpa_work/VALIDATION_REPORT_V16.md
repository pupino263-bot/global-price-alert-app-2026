# Global Price Alert — validation report

**Package reviewed:** V15 source archive, refreshed into V16 documentation on 13 October 2026.

## Checks actually executed in this workspace

| Check | Result | Evidence / command |
|---|---|---|
| Backend automated test suites | PASS | `cd backend && npm test` |
| Static release preflight | PASS | `node scripts/release-preflight.mjs` — 16 required files and safety guards |
| Backend JS syntax | PASS | `node --check` on every `backend/src/*.mjs` and `backend/test/*.mjs` |
| Android XML parsing | PASS | Python XML parser on all `*.xml` files under the project |
| ZIP integrity of incoming V15 archive | PASS | `unzip -t GlobalPriceAlert-Android-MVP-v15.zip` |
| Java runtime present | PASS | OpenJDK 21 detected |
| Gradle executable available locally | NOT AVAILABLE | `gradle` command not found |
| Android SDK / `android.jar` available locally | NOT AVAILABLE | No SDK installation found in standard locations |
| Android Gradle build / APK | NOT RUN | Requires Gradle, Android SDK and dependency downloads |
| Real-device / emulator test | NOT RUN | No device/emulator attached to this workspace |
| Production backend / live store integration | NOT RUN | Requires deployment, HTTPS endpoint and authorized credentials |
| Signed Play App Bundle | NOT GENERATED | Requires verified release build and secure signing setup |

## Important interpretation

A passing backend test suite and static preflight do **not** mean the Android app is compiled or ready for public release. The CI workflow is configured to install JDK, Gradle 8.11.1 and Android SDK API 36, then run `gradle assembleDebug` and upload the debug APK. That remote job must actually run successfully before an Android build can be marked verified.

## Release blockers still open

1. Obtain a successful Android CI build; inspect the APK and install it on an emulator or physical Android device.
2. Deploy the backend over HTTPS, provision PostgreSQL, apply migrations and validate production configuration.
3. Connect and verify at least one authorized live store source; do not present mock listings as live prices.
4. End-to-end test authentication/session handling, account deletion, history, alerts and push notifications.
5. Complete Italian, English, French, Spanish and German UI localization and manual language selection.
6. Implement server-verified Google Play Billing before enabling Premium purchases.
7. Configure consent-compliant ads and affiliate integrations, privacy policy, terms, support and Play data disclosures.
8. Create a securely signed release AAB and complete Play internal testing before production rollout.

Credentials and signing keys are intentionally not included in this package.

# Global Price Alert — tassonomia categorie, copertura aggiuntiva

## Categorie aggiunte

- Gioielli e bigiotteria
- Artigianato, filati e merceria
- Tatuaggi e body art
- Integratori e nutrizione sportiva
- Riscaldamento, climatizzazione ed energia
- Domotica, reti e automazione
- Macchinari e impianti industriali
- Idraulica e trattamento acqua
- Software e servizi digitali

Ogni categoria eredita automaticamente i cinque rami trasversali condivisi definiti nel codice: accessori e complementi; componenti e ricambi; consumabili; prodotti compatibili; varianti professionali e specialistiche. La lista dettagliata delle sottocategorie è nel file `app/src/main/java/com/globalpricealert/app/CategoryTaxonomy.kt`.

## Controlli aggiunti

Lo script `scripts/release-preflight.mjs` verifica che le categorie richieste siano presenti, che i nomi di primo livello siano univoci e che la copertura superi la soglia minima. Questo è un controllo statico del sorgente, non un test UI.

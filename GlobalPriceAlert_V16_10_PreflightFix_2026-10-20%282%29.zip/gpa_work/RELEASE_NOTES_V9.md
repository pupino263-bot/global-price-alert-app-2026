# Global Price Alert V9 — release notes

## Implemented in this iteration
- AES-GCM encrypted Android session token persistence backed by Android Keystore.
- Session restore after app process restart (code implemented; device verification pending).
- Local credential clearing on logout, successful account deletion and API HTTP 401.
- Password masking in the account dialog.
- Notification inbox UI backed by the authenticated notification API; mark-as-read action.

## Verification performed
- `npm test` in backend: PASS.
- `node --check` for all backend source/test modules: PASS.
- `kotlinc` compilation of pure Kotlin domain/taxonomy/architecture: PASS.
- XML parsing of Android manifests/styles: PASS.
- Static checks for SessionVault encryption and notification UI/client wiring: PASS.

## Not claimed as complete
- Full Android Gradle/Compose build and signed AAB.
- Android Keystore/session restoration/notification UI tests on emulator or device.
- FCM push delivery, full five-language localization, live PostgreSQL, live marketplace credentials, Google Play Billing, affiliate conversion postbacks, deployment and Play Console review.

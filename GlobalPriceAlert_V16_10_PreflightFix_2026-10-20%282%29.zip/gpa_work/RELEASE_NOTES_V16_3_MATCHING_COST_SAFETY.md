# Release notes — V16.3 Matching & Cost Safety

**Date:** 18 October 2026

## Changes
- Smart Matching no longer trusts any 8–14 digit string as a GTIN. It accepts only standard GTIN-8, UPC/GTIN-12, GTIN-13 and GTIN-14 lengths with a valid GS1 check digit; arbitrary letters in the code field are rejected rather than stripped; invalid codes fall back to brand/model/title identity.
- Effective-cost normalization now fails closed: shipping, taxes and mandatory fees must each be explicitly declared known before an offer can be treated as a complete total. Missing data is still retained for comparison, but marked as estimated so the UI and alert logic cannot mistake it for a verified total.
- Discounts larger than the gross known amount are rejected instead of being silently clamped to a fabricated zero price.
- Added regression tests for valid GTIN lengths, bad check digits, unsupported GTIN length, incomplete cost declarations and over-large discounts.
- Extended release preflight so these matching and cost-safety invariants are checked on every CI preflight run.

## Verification
- Static release preflight: PASS.
- Backend automated test suite: PASS (all four test groups).
- Full Android Gradle build, device test, live marketplace access and production database: NOT RUN / NOT VERIFIED in this environment.

# Global Price Alert V16.4 — Variant-aware matching & Smart Compatibility

**Date:** 19 October 2026  
**Type:** backend source increment; not an Android release build.

## Implemented

- Variant-aware normalized product identity for non-GTIN offers, preserving storage/capacity, common color aliases, sizes and selected structured attributes where present.
- Shared `productFamilyKey` and `variantSignature` fields so related variants can be recognized as a family without mixing their price ranking.
- Conservative Smart Compatibility assessment in `backend/src/compatibility.mjs`.
- New `POST /v1/compatibility/check` endpoint returning `confirmed`, `likely`, `incompatible` or `unknown` with evidence and an explicit verification disclaimer.
- Compatibility behavior documented in OpenAPI.
- Added unit and API integration tests; release preflight now requires the compatibility module and regression tests.

## Safety rules

- A matching part/OEM number can confirm a match.
- A hard mismatch in known voltage, connector, dimensions or size marks a candidate incompatible.
- Different part numbers alone do not prove incompatibility.
- Missing evidence remains `unknown`; the API does not claim fitment based only on product title.
- Different material variants must not be merged for price ranking.

## Verification performed

- `npm test --prefix backend`: PASS (source, compatibility, eBay mocked adapter, alert monitoring and API integration tests).
- `node scripts/release-preflight.mjs`: PASS (17 required files and release guards).
- No Gradle build, Android APK/AAB, live marketplace call or production database test was run in this environment.

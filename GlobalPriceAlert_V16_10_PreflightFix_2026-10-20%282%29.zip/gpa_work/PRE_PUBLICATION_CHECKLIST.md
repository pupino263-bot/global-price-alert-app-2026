# Global Price Alert — pre-publication checklist

This checklist separates checks executable in the repository from tasks requiring external services, credentials, devices, or legal/business decisions. Do not publish until every release-blocking item is verified.

## Verified in this package
- [x] Backend automated tests pass locally (`cd backend && npm test`) — re-run 13 Oct 2026; see `VALIDATION_REPORT_V16.md`.
- [x] Static release preflight passes (`node scripts/release-preflight.mjs`) — re-run 13 Oct 2026; see `VALIDATION_REPORT_V16.md`.
- [x] All backend source and test JavaScript files pass `node --check` — re-run 13 Oct 2026.
- [x] All Android XML files parse — re-run 13 Oct 2026.
- [x] Incoming V15 ZIP archive integrity passes; V16 package is rebuilt after documentation refresh.
- [x] CI runs backend tests and release preflight, and has an Android debug build/artifact job.

## Must complete before public release
- [ ] Run the full Android Gradle build in CI and inspect the generated APK; run the app on a physical Android device or emulator.
- [ ] Verify search, login, logout, account deletion, notifications, price history and alert flows end-to-end against a deployed HTTPS backend.
- [ ] Deploy PostgreSQL and backend; apply migrations and test production configuration, backups, logging, rate limits and recovery.
- [ ] Connect at least one approved live store API and confirm real listings, currency, stock, shipping and total-cost semantics. Clearly label unknown/estimated fees.
- [ ] Complete Italian, English, French, Spanish and German UI localization, including a manual language selector and device-locale default.
- [ ] Implement and test Google Play Billing entitlement verification before selling Premium; do not unlock Premium locally.
- [ ] Configure ads, affiliate tracking and push notifications only after required provider accounts/consents are ready.
- [ ] Finalize and publish privacy policy, terms, support contact, data-safety disclosures, account-deletion disclosures and store listing assets.
- [ ] Configure release signing securely and generate a signed Android App Bundle (AAB); never place signing keys or production secrets in the ZIP/repository.
- [ ] Complete Google Play internal testing and resolve policy, stability and compatibility issues before production rollout.

## Environment limitation
The current workspace has no installed Gradle executable, Android SDK or Android Gradle wrapper, so a full Android build and signed AAB cannot be truthfully marked as completed here. The GitHub Actions Android job is the intended build path once this project is pushed to its repository.

## Toolchain Android
- [x] Versioni richieste definite: Gradle 8.11.1, JDK 17/21, SDK API 36, Build Tools 36.0.0.
- [x] Script di bootstrap Linux e Windows aggiunti al pacchetto.
- [x] Workflow CI configurato per installare SDK/Gradle e compilare l'APK debug.
- [ ] Eseguire il bootstrap e la compilazione completa su una macchina con Internet: questo ambiente di lavoro non riesce a risolvere host esterni e non può scaricare qui i pacchetti ufficiali.

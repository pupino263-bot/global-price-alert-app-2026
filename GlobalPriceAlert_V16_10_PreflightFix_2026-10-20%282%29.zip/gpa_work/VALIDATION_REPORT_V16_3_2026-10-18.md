# Global Price Alert — Validation Report V16.3

**Date:** 18 October 2026  
**Scope:** source normalization, Smart Matching identity, effective-cost certainty and static release guards.

## Changes implemented

1. Added GS1 check-digit validation for GTIN-8, GTIN-12/UPC, GTIN-13/EAN and GTIN-14.
2. Invalid check digits, unsupported GTIN lengths and arbitrary letters in the GTIN field no longer become exact-match product keys; identity falls back to brand/model or title/category.
3. An offer is treated as an estimated total unless shipping, taxes and mandatory fees are each explicitly declared known. Missing components are not silently interpreted as zero for a definitive comparison.
4. Discounts larger than price + shipping + mandatory fees + taxes are rejected instead of being clamped to a fabricated zero effective cost.
5. Extended automated tests and release preflight to protect these rules against regressions.

## Verification results observed

| Check | Result |
|---|---|
| `node scripts/release-preflight.mjs` | PASS |
| `cd backend && npm test` | PASS — all four test groups |
| `node --check` for `.mjs` under backend source/tests and scripts | PASS |
| `kotlinc` for `Domain.kt`, `CategoryTaxonomy.kt`, `Architecture.kt` | PASS |
| XML parsing of Android main resources/manifest | PASS — 2 XML files |
| Source ZIP integrity after packaging | PASS |
| Re-run preflight and backend tests from extracted packaged ZIP | PASS |

Regression cases added include valid GTIN-8/12/13/14, invalid check digit, invalid length, alphabetic contamination in GTIN, missing cost certainty and discount exceeding gross amount.

## Explicitly not verified

- Full Android Gradle/Compose build (`assembleDebug`/`assembleRelease`).
- APK installation, device/emulator tests, crash/logcat review.
- Signed AAB, signing key custody and Play Console upload.
- Live eBay credentials/API results, live PostgreSQL migrations, deployed HTTPS backend.
- Google Play Billing verification, ads, affiliate network attribution, push delivery and production monitoring.
- Complete IT/EN/FR/ES/DE localization and legal/store declarations.

The current environment has Java and `kotlinc`, but no Gradle executable or Android SDK was found. Therefore no APK/AAB is claimed.

## Release decision

V16.3 is a safer source package for matching and price-total semantics, but it is **not yet a release candidate** until the Android build and production integration gates above are passed.
